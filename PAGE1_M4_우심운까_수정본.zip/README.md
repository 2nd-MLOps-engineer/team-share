# 우심운까 M4 · PAGE 1

지도 중심 지역·친구 운동 경쟁 랜딩 화면입니다. M1 통합 전용으로 PAGE 1 범위만 포함합니다.

## 산출물

- `dist/index.html`: PAGE 1 템플릿
- `dist/landing.css`: PAGE 1 스타일과 반응형
- `dist/landing.js`: 지도·지역·친구 랭킹 컴포넌트 로직
- `dist/services/rankingApi.js`: API/Mock 교체 인터페이스
- `dist/mock/rankings.js`: 실행 가능한 Mock 데이터
- `dist/mock/rankings.json`: API Contract 요약

## 실행

정적 서버에서 `dist/`를 서비스합니다. 실제 API 연결 시 페이지 로드 전에 `globalThis.USIMUNKKA_USE_MOCK = false`, `globalThis.USIMUNKKA_API_BASE = "..."`를 설정합니다.

CTA 기본 경로는 `/recommend`입니다. 최종 라우팅은 M1이 통합 단계에서 조정합니다.
