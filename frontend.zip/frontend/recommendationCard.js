export function createRecommendationCard(recommendation, index = 0) {
    const card = document.createElement("article");
    card.className = "recommendation-card";

    const rank = document.createElement("div");
    rank.className = "recommendation-rank";
    rank.textContent = String(index + 1).padStart(2, "0");

    const info = document.createElement("div");
    info.className = "recommendation-info";

    const sport = document.createElement("span");
    sport.className = "recommendation-sport";
    sport.textContent =
        recommendation.sport ||
        recommendation.sport_name ||
        "SPORT";

    const title = document.createElement("h3");
    title.textContent =
        recommendation.name ||
        recommendation.facility_name ||
        "추천 운동 시설";

    const meta = document.createElement("p");

    const distance =
        recommendation.distance ??
        recommendation.distance_km ??
        "-";

    const travelTime =
        recommendation.travel_time ??
        recommendation.travel_minutes ??
        "-";

    meta.textContent =
        `DISTANCE ${distance} / TRAVEL ${travelTime} MIN`;

    info.appendChild(sport);
    info.appendChild(title);
    info.appendChild(meta);

    const arrow = document.createElement("div");
    arrow.className = "recommendation-arrow";
    arrow.textContent = "↗";

    card.appendChild(rank);
    card.appendChild(info);
    card.appendChild(arrow);

    return card;
}
