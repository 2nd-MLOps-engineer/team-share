// 우심운까 - 내 지역 추천 전용 엔트리
// 추천 지역의 유일한 원천: Django 세션 profile.city
window.USIMUNKKA_RECOMMEND_MODE = "home";

(() => {
  const MODE = "home";
  const MODE_LABEL = "MY REGION";

  const SPORT_META = {
    RUNNING: {
      ko: "러닝",
      en: "RUNNING",
      place: "지역 러닝 코스 후보",
      description: "공원·하천·생활권 코스를 기준으로 보는 테스트 추천",
      tags: ["야외", "유산소", "페이스 조절"],
    },
    CYCLING: {
      ko: "자전거",
      en: "CYCLING",
      place: "지역 자전거 코스 후보",
      description: "자전거 도로와 순환 동선을 기준으로 보는 테스트 추천",
      tags: ["라이딩", "유산소", "거리 확장"],
    },
    HYROX: {
      ko: "하이록스",
      en: "HYROX",
      place: "기능성 트레이닝 시설 후보",
      description: "러닝과 근력 인터벌이 가능한 공간을 가정한 테스트 추천",
      tags: ["고강도", "근지구력", "인터벌"],
    },
    FITNESS: {
      ko: "헬스",
      en: "FITNESS",
      place: "피트니스 센터 후보",
      description: "웨이트와 유산소 장비를 함께 사용할 수 있다고 가정한 테스트 추천",
      tags: ["근력", "실내", "자유 운동"],
    },
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const escapeHtml = (value = "") => String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  const button = $("#recommendBtn");
  const result = $("#result");
  const regionEl = $("#resultRegion");
  const timeEl = $("#resultTime");
  const travelEl = $("#resultTravel");
  const availableSelect = $("#availableMinutes");
  const travelSelect = $("#travelMinutes");
  const transportSelect = $("#transport");
  const manualLocation = $("#manualLocation");

  if (!button || !result) return;

  function getRegion() {
    // home 페이지에서는 사용자가 입력창을 수정해도 추천 지역 원천은 세션 지역이다.
    return regionEl?.textContent?.trim() || "내 지역";
  }

  function getTransportLabel() {
    const option = transportSelect?.selectedOptions?.[0];
    return option?.textContent?.trim() || "이동수단";
  }

  function updateSummary() {
    const available = Number(availableSelect?.value || 90);
    const travel = Number(travelSelect?.value || 20);
    if (timeEl) timeEl.textContent = `${available} MIN`;
    if (travelEl) travelEl.textContent = `${travel} MIN`;
  }

  function imageForSport(value) {
    const input = $(`input[name="sport"][value="${value}"]`);
    return input?.closest(".sport-option")?.querySelector("img")?.src || "";
  }

  function renderEmpty() {
    result.innerHTML = `
      <div class="mock-result-empty" role="status">
        <span class="mock-result-empty-kicker">ONE MORE STEP</span>
        <strong>하고 싶은 운동을 하나 이상 선택해 주세요.</strong>
        <p>러닝, 자전거, 하이록스, 헬스 중 선택한 종목을 기준으로 테스트 결과를 보여드릴게요.</p>
      </div>`;
  }

  function renderResults() {
    updateSummary();

    const selected = $$("input[name='sport']:checked").map((input) => input.value);
    if (!selected.length) {
      renderEmpty();
      $(".sports-visual-grid")?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    const region = getRegion();
    const available = Number(availableSelect?.value || 90);
    const travel = Number(travelSelect?.value || 20);
    const workoutMinutes = Math.max(10, available - travel);
    const transport = getTransportLabel();
    const startLocation = manualLocation?.value?.trim() || region;

    result.innerHTML = selected.map((value, index) => {
      const meta = SPORT_META[value];
      const image = imageForSport(value);
      if (!meta) return "";

      return `
        <article class="mock-result-card" data-sport="${escapeHtml(value)}">
          <div class="mock-result-media">
            ${image ? `<img src="${escapeHtml(image)}" alt="${escapeHtml(meta.ko)} 테스트 추천 이미지">` : ""}
            <span class="mock-result-media-shade" aria-hidden="true"></span>
            <span class="mock-result-order">0${index + 1}</span>
            <span class="mock-result-mode">${MODE_LABEL}</span>
          </div>

          <div class="mock-result-body">
            <div class="mock-result-title-row">
              <div>
                <span class="mock-result-kicker">TEST PICK · ${escapeHtml(meta.en)}</span>
                <h3>${escapeHtml(meta.ko)} · ${escapeHtml(region)}</h3>
              </div>
              <span class="mock-result-badge">MOCK</span>
            </div>

            <strong class="mock-result-place">${escapeHtml(meta.place)}</strong>
            <p class="mock-result-description">${escapeHtml(meta.description)}</p>

            <div class="mock-result-stats">
              <div><span>출발</span><strong>${escapeHtml(startLocation)}</strong></div>
              <div><span>이동</span><strong>${travel}분 이내</strong></div>
              <div><span>운동 가능</span><strong>약 ${workoutMinutes}분</strong></div>
              <div><span>수단</span><strong>${escapeHtml(transport)}</strong></div>
            </div>

            <div class="mock-result-tags">
              ${meta.tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join("")}
            </div>

            <p class="mock-result-note">※ 실제 시설 검색 결과가 아닌 UI·흐름 확인용 테스트 데이터입니다.</p>
          </div>
        </article>`;
    }).join("");

    result.querySelector(".mock-result-card")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  button.addEventListener("click", renderResults);
  availableSelect?.addEventListener("change", updateSummary);
  travelSelect?.addEventListener("change", updateSummary);
  updateSummary();

  console.log(`USIMUNKKA ${MODE}-region test recommendation ready`);
})();
