const filterButtons = document.querySelectorAll(".filter-chip");
const cards = document.querySelectorAll(".shop-card");

filterButtons.forEach(button => {
    button.addEventListener("click", () => {
        const filter = button.dataset.filter;

        filterButtons.forEach(item => {
            item.classList.remove("active");
        });

        button.classList.add("active");

        cards.forEach(card => {
            if (filter === "all") {
                card.classList.remove("hidden");
                return;
            }

            const categories =
                (card.dataset.category || "")
                    .split(" ");

            if (categories.includes(filter)) {
                card.classList.remove("hidden");
            } else {
                card.classList.add("hidden");
            }
        });
    });
});
