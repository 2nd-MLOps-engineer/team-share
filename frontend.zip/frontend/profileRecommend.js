// 기존 recommend.js와 이 파일을 동시에 불러오지 마세요.
const config = document.querySelector("#profileDemoConfig");
const initialProfile = document.querySelector("#usimunkka-profile");

if (!config || !initialProfile) {
    console.error("profile_scope.html include가 필요합니다.");
} else {
    initializeProfileRecommendations();
}

function initializeProfileRecommendations() {
    const result = document.querySelector("#result");
    const recommendBtn = document.querySelector("#recommendBtn");
    const locationBtn = document.querySelector("#locationBtn");
    const manualLocation = document.querySelector("#manualLocation");
    const available = document.querySelector("#availableMinutes");
    const travel = document.querySelector("#travelMinutes");
    const transport = document.querySelector("#transport");

    if (![result, recommendBtn, locationBtn, manualLocation, available, travel, transport].every(Boolean)) {
        console.error("기존 추천 화면의 입력 요소 ID를 확인해주세요.");
        return;
    }

    const AGE_LABELS = {
        "10s": "10대", "20s": "20대", "30s": "30대",
        "40s": "40대", "50s": "50대", "60_plus": "60대 이상"
    };
    const SPORT_LABELS = {
        RUNNING: "러닝", SWIMMING: "수영", BADMINTON: "배드민턴"
    };
    let profile;
    try {
        profile = JSON.parse(initialProfile.textContent);
    } catch {
        result.textContent = "프로필 정보를 읽지 못했어요. 내 정보를 다시 저장해주세요.";
        return;
    }
    let departure = { latitude: null, longitude: null };
    let pending = false;
    let locating = false;
    const originalButtonText = recommendBtn.textContent.trim();

    function textElement(tag, text, className) {
        const node = document.createElement(tag);
        node.textContent = text;
        if (className) node.className = className;
        return node;
    }

    function updateScope(savedProfile) {
        profile = savedProfile;
        document.querySelector("#scopeNickname").textContent = profile.nickname;
        document.querySelector("#scopeCity").textContent = profile.city;
        document.querySelector("#scopeAge").textContent =
            ` · ${profile.age_label || AGE_LABELS[profile.age_group] || "나이대 정보 없음"}`;
        manualLocation.value = profile.city;
        manualLocation.readOnly = true;
        manualLocation.setAttribute("aria-label", "프로필에 저장한 추천 지역");
        manualLocation.title = "변경하려면 내 정보 수정을 눌러주세요.";

        const locationSection = manualLocation.closest(".form-section, .form-group");
        const title = locationSection?.querySelector("h3");
        const hint = locationSection?.querySelector(".form-title p");
        if (title) title.textContent = "추천 지역 / 출발 위치";
        if (hint) hint.textContent = "거주 지역은 고정이고, 현재 출발 위치는 선택 사항이에요.";
        const orText = locationSection?.querySelector(".or-text");
        if (orText) orText.textContent = "추천 지역";
    }

    function setBusy(value) {
        pending = value;
        recommendBtn.disabled = value;
        locationBtn.disabled = value || locating;
        available.disabled = value;
        travel.disabled = value;
        transport.disabled = value;
        document.querySelectorAll('input[name="sport"]').forEach((el) => {
            el.disabled = value;
        });
        recommendBtn.textContent = value ? "시설 후보를 확인하고 있어요..." : originalButtonText;
        result.setAttribute("aria-busy", String(value));
    }

    function showMessage(message, error = false) {
        const panel = textElement("div", message, "profile-demo-result");
        panel.setAttribute("role", error ? "alert" : "status");
        result.replaceChildren(panel);
        return panel;
    }

    function addLoginLink(panel) {
        const p = document.createElement("p");
        const link = textElement("a", "내 정보 입력 / 수정", "profile-demo-link");
        link.href = config.dataset.loginUrl;
        p.append(link);
        panel.append(p);
    }

    function clearOldResults() {
        if (!pending) {
            showMessage("조건이 바뀌었어요. 버튼을 눌러 해당 지역의 후보를 다시 확인해주세요.");
        }
    }

    function renderResults(data) {
        updateScope(data.applied_profile);
        result.replaceChildren();

        const summary = document.createElement("div");
        summary.className = "profile-demo-result";
        summary.setAttribute("role", "status");
        summary.append(
            textElement("strong", `${profile.city} · 샘플 후보 ${data.recommendations.length}곳`),
            textElement("p", data.notice, "profile-demo-meta")
        );
        result.append(summary);

        if (data.recommendations.length === 0) {
            const panel = textElement(
                "div",
                `${profile.city}에 현재 조건과 맞는 샘플 데이터가 없습니다. 다른 지역 자료로 대신 채우지 않습니다. 실제 시설이 없다는 뜻은 아닙니다.`,
                "profile-demo-result"
            );
            addLoginLink(panel);
            result.append(panel);
            return;
        }

        for (const item of data.recommendations) {
            const card = document.createElement("article");
            card.className = "profile-demo-result";
            card.append(
                textElement("span", "MOCK · 확인 필요", "profile-demo-badge"),
                textElement("h3", item.facility_name),
                textElement("p", `${item.city} · ${SPORT_LABELS[item.sport] || "종목 확인 필요"}`),
                textElement("p", item.program_name, "profile-demo-meta"),
                textElement("p", "추천점수 · 이동시간 · 운동 가능시간: 아직 확인하지 않음", "profile-demo-meta")
            );

            const reasons = document.createElement("ul");
            for (const reason of item.reasons || []) {
                reasons.append(textElement("li", reason));
            }
            card.append(reasons);
            card.append(
                textElement("p", (item.warnings || []).join(" "), "profile-demo-warning")
            );
            result.append(card);
        }
    }

    async function handleRecommendation() {
        if (pending) return;

        const sports = Array.from(
            document.querySelectorAll('input[name="sport"]:checked'),
            (item) => item.value
        );
        if (!sports.length) {
            showMessage("운동 종목을 하나 이상 선택해주세요.", true);
            document.querySelector('input[name="sport"]')?.focus();
            return;
        }

        const requestData = {
            available_minutes: Number(available.value),
            max_travel_minutes: Number(travel.value),
            transport: transport.value,
            sports,
            ...departure,
        };
        // nickname / age_group / city는 보내지 않습니다.
        // 서버가 세션에서 읽으므로 화면 값 변경으로 추천 지역이 바뀌지 않습니다.
        const csrfToken = config.querySelector('[name="csrfmiddlewaretoken"]')?.value;
        if (!csrfToken) {
            showMessage("CSRF 토큰이 없습니다. 페이지를 새로고침해주세요.", true);
            return;
        }

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 10000);
        setBusy(true);
        showMessage("프로필 지역 안에서 샘플 시설을 찾고 있어요...");

        try {
            const response = await fetch(config.dataset.apiUrl, {
                method: "POST",
                mode: "same-origin",
                credentials: "same-origin",
                cache: "no-store",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "X-CSRFToken": csrfToken,
                },
                body: JSON.stringify(requestData),
                signal: controller.signal,
            });

            if (response.status === 401) {
                const panel = showMessage("프로필이 없거나 만료되었습니다. 내 정보를 다시 입력해주세요.", true);
                addLoginLink(panel);
                return;
            }

            const isJSON = response.headers.get("content-type")?.includes("application/json");
            const data = isJSON ? await response.json() : null;
            if (!response.ok) {
                throw new Error(
                    data?.error || `요청 실패 (${response.status}). URL 연결 또는 CSRF 설정을 확인해주세요.`
                );
            }
            if (
                data?.mode !== "MOCK"
                || !data.applied_profile?.city
                || !Array.isArray(data.recommendations)
            ) {
                throw new Error("개발용 API 응답 형식이 예상과 다릅니다.");
            }
            // 오류가 난 서버 응답을 조용히 정상 결과처럼 표시하지 않습니다.
            if (data.recommendations.some((item) => item.city !== data.applied_profile.city)) {
                throw new Error("서버가 프로필과 다른 지역의 시설을 반환했습니다.");
            }
            renderResults(data);
        } catch (error) {
            const message = error.name === "AbortError"
                ? "응답 시간이 초과되었습니다. 다시 시도해주세요."
                : error.message;
            const panel = showMessage(message, true);
            const retry = textElement("button", "다시 시도", "profile-demo-action");
            retry.type = "button";
            retry.addEventListener("click", handleRecommendation);
            panel.append(document.createElement("br"), retry);
        } finally {
            clearTimeout(timer);
            setBusy(false);
        }
    }

    locationBtn.textContent = "현재 출발 위치 추가 (선택)";
    locationBtn.addEventListener("click", () => {
        if (locating || pending) return;
        const status = document.querySelector("#departureStatus");
        if (!navigator.geolocation) {
            status.textContent = "위치 기능을 사용할 수 없어요. 거주 지역 기준 샘플 조회는 가능합니다.";
            return;
        }
        locating = true;
        locationBtn.disabled = true;
        status.textContent = "출발 위치를 확인하고 있어요...";
        navigator.geolocation.getCurrentPosition(
            (position) => {
                departure = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                };
                locating = false;
                locationBtn.disabled = pending;
                status.textContent = "출발 위치를 받았습니다. 추천 지역은 그대로이며, 이동시간 계산은 아직 미연동입니다.";
                clearOldResults();
            },
            () => {
                departure = { latitude: null, longitude: null };
                locating = false;
                locationBtn.disabled = pending;
                status.textContent = "출발 위치 없이 거주 지역 기준으로 진행할 수 있어요.";
            },
            { timeout: 10000, maximumAge: 0, enableHighAccuracy: false }
        );
    });

    recommendBtn.addEventListener("click", (event) => {
        event.preventDefault();
        handleRecommendation();
    });
    for (const element of [available, travel, transport]) {
        element.addEventListener("change", clearOldResults);
    }
    document.querySelectorAll('input[name="sport"]').forEach((el) => {
        el.addEventListener("change", clearOldResults);
    });

    window.addEventListener("pageshow", (event) => {
        // 브라우저 뒤로 가기에 저장된 이전 프로필 화면을 재사용하지 않습니다.
        if (event.persisted) window.location.reload();
    });

    updateScope(profile);
    showMessage(`${profile.city}에 한정해 찾습니다. 운동 종목을 선택한 뒤 버튼을 눌러주세요.`);
}
