const form = document.getElementById("profileForm");
const nickname = document.getElementById("nickname");
const ageGroup = document.getElementById("age_group");
const city = document.getElementById("city");
const status = document.getElementById("profileStatus");
const startBtn = document.getElementById("startBtn");

function refreshPreview() {
    document.getElementById("previewNickname").textContent =
        nickname.value.trim() || "어떤 운동 친구인가요?";

    document.getElementById("previewAge").textContent =
        ageGroup.value || "나이대 선택";

    document.getElementById("previewCity").textContent =
        city.value.trim() || "사는 도시";
}

form.addEventListener("input", refreshPreview);
refreshPreview();

form.addEventListener("submit", (event) => {
    const name = nickname.value.trim();
    const region = city.value.trim();

    if (!form.reportValidity()) {
        event.preventDefault();
        return;
    }

    if (!name || !region || /[<>]/.test(name + region)) {
        event.preventDefault();
        status.textContent =
            "닉네임과 도시를 확인해주세요. 꺾쇠 기호는 사용할 수 없어요.";
        return;
    }

    status.textContent = "프로필을 저장하고 메인페이지로 이동합니다.";
    startBtn.disabled = true;
    startBtn.textContent = "저장 중...";
});
