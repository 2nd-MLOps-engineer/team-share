/*
USIMUNKKA Recommendation API Adapter

현재는 프론트엔드 개발용 Mock 데이터를 사용합니다.
M2 실제 API 연결 시 USE_MOCK을 false로 바꾸고
아래 fetch 경로/API 계약을 팀과 합의한 내용에 맞춰 연결하세요.
*/

const USE_MOCK = true;

const MOCK_RECOMMENDATIONS = [
    {
        id: 1,
        name: "한강 러닝 코스",
        sport: "RUNNING",
        distance: "1.3 KM",
        travel_time: 12
    },
    {
        id: 2,
        name: "도심 라이딩 코스",
        sport: "CYCLING",
        distance: "2.1 KM",
        travel_time: 15
    },
    {
        id: 3,
        name: "HYROX TRAINING CLUB",
        sport: "HYROX",
        distance: "2.8 KM",
        travel_time: 19
    },
    {
        id: 4,
        name: "퍼포먼스 피트니스 센터",
        sport: "FITNESS",
        distance: "1.7 KM",
        travel_time: 14
    }
];

function getMockRecommendations(requestData) {
    const selectedSports =
        (requestData.sports || [])
            .map(value => String(value).toLowerCase());

    const filtered =
        MOCK_RECOMMENDATIONS.filter(item =>
            selectedSports.includes(
                String(item.sport).toLowerCase()
            )
        );

    return {
        recommendations: filtered
    };
}

export async function getRecommendations(requestData) {
    console.log("Recommendation Request:", requestData);

    if (USE_MOCK) {
        await new Promise(resolve => {
            setTimeout(resolve, 650);
        });

        return getMockRecommendations(requestData);
    }

    const response = await fetch(
        "/api/recommendations/",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(requestData)
        }
    );

    if (!response.ok) {
        throw new Error(
            `Recommendation API failed: ${response.status}`
        );
    }

    return await response.json();
}
