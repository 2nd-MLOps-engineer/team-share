우심운까 PAGE1 + PAGE2 연결본

실행: 압축을 모두 푼 뒤 index.html을 여세요.
운동 찾으러 가기 → recommend.html
추천 화면 상단 우심운까 로고 → index.html

GitHub Pages: index.html, recommend.html, recommend.css를 같은 폴더에 올리세요.

PAGE1은 최종 저장본의 디자인과 기존 동작을 유지하고 CTA 경로만 수정했습니다.
PAGE2는 제공된 M1 HTML/CSS를 사용하고 Django static 경로를 상대 경로로 변경했습니다.
제공 ZIP에 recommend.js가 없어 현재 위치 및 추천 실행 버튼은 준비 중으로 표시했습니다. 실제 추천/API 연결은 포함되지 않습니다.
