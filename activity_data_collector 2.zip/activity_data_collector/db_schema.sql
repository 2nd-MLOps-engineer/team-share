-- 참고용 PostgreSQL 스키마입니다.
-- 이 프로젝트의 collector.py는 이 파일을 실행하지 않으며 DB에도 접속하지 않습니다.

CREATE TABLE sports_facilities (
    id BIGSERIAL PRIMARY KEY,
    facility_name TEXT NOT NULL,
    facility_type TEXT,
    address TEXT,
    city TEXT,
    district TEXT,
    phone TEXT,
    homepage TEXT,
    latitude NUMERIC(10, 7),
    longitude NUMERIC(10, 7),
    web_status TEXT,
    web_evidence TEXT,
    source_row JSONB,
    collected_at TIMESTAMPTZ NOT NULL,
    UNIQUE (facility_name, address)
);

CREATE INDEX sports_facilities_region_idx
    ON sports_facilities (city, district);
