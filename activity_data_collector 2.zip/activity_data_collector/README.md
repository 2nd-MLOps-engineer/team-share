# 운동 장소 데이터 확인기

DB에 접속하지 않고 기상청·에어코리아·전국체육시설 정보를 받아 `output/`에 JSON과 CSV로 저장합니다. PostgreSQL 접속 정보나 드라이버는 이 폴더에 포함하지 않습니다.

## 준비

```bash
cd /Users/khj/Desktop/activity_data_collector
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

`.env`에 세 서비스의 **일반 인증키(Decoding)**를 입력합니다. 전국체육시설 정보 API는 공공데이터포털의 [서비스 페이지](https://www.data.go.kr/data/15113986/openapi.do)에서 활용신청한 뒤 명세의 요청 URL이 다르면 `FACILITY_API_URL`을 바꾸세요.

## 실행

```bash
python collector.py --region 수원시 --station 수원 --nx 60 --ny 120
```

## 로그인 지역 기반 웹페이지

DB 없이 로그인한 프로필의 지역을 기준으로 첫 페이지에서 추천 데이터를
미리 계산하고, 두 번째 페이지는 지역별 캐시를 즉시 표시합니다.

```bash
cd /Users/khj/Desktop/activity_data_collector
source .venv/bin/activate
python web_app.py
```

브라우저에서 `http://127.0.0.1:5050`으로 접속하세요. 로그인 화면에서
닉네임과 지역을 입력하면 해당 지역의 날씨·대기질·시설 추천 결과를 먼저
계산한 뒤 `output/recommend_cache/`에 저장합니다. 현재 위치 기능은 아직
사용하지 않습니다.

시설 홈페이지까지 보완 확인하려면 다음 옵션을 추가합니다.

```bash
python collector.py --region 수원시 --station 수원 --nx 60 --ny 120 --enrich-web --limit 20
```

결과:

- `output/latest.json`: 원자료, API 응답, 통합 결과, 보완 확인 결과
- `output/facilities.csv`: 시설별 확인용 표
- `output/facilities_normalized.json`: 다른 컴퓨터에서 DB 적재하기 쉬운 정규화 시설 목록
- `output/raw/`: 서비스별 원본 응답

나중에 다른 컴퓨터에서 PostgreSQL로 옮길 때는 `facilities_normalized.json` 또는 `facilities.csv`를 적재하면 됩니다. [db_schema.sql](db_schema.sql)은 참고용 SQL 파일일 뿐이며 이 프로그램이 실행하거나 DB를 생성하지 않습니다.

## 데이터 보완 방식

1. 전국체육시설 API에서 시설 기본정보를 받습니다.
2. 시설의 시도·시군구·주소·좌표를 이용해 날씨와 측정소 정보를 붙입니다.
3. `--enrich-web`일 때만 API 결과에 있는 홈페이지 URL을 대상으로 robots.txt를 확인하고, 해당 홈페이지의 공개 텍스트에서 운영시간·휴관·공사·임시 제한 관련 문구를 추출합니다.

홈페이지가 없거나 robots.txt에서 허용되지 않으면 크롤링하지 않습니다. 공지의 진위나 현재 운영 여부를 자동으로 확정하지 않고 `web_evidence`로만 남깁니다.

기상청 단기예보 API는 발표 주기 기반이므로 이 프로그램을 여러 번 실행하면 최신 발표값을 확인할 수 있지만, 초단위 실시간 스트리밍은 아닙니다. 서비스 운영 시에는 서버 작업 스케줄러로 주기 실행하고 결과를 캐시하면 됩니다.
