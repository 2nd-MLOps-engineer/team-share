from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("frontend", "0001_initial")]

    operations = [
        migrations.CreateModel(
            name="Member",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=50)),
                ("nickname", models.CharField(max_length=20, unique=True)),
                ("password_hash", models.CharField(max_length=128)),
                ("address", models.CharField(max_length=200)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
