from django.urls import path

from . import auth_views
from . import views as legacy_views


urlpatterns = [
    # Opening / account
    path("", auth_views.welcome, name="welcome"),
    path("signup/", auth_views.signup_page, name="signup"),
    path("login/", auth_views.login_page, name="login"),
    path("guest/start/", auth_views.guest_start, name="guest_start"),
    path("logout/", auth_views.logout_page, name="logout"),
    path("api/check-member-nickname/", auth_views.check_member_nickname, name="check_member_nickname"),

    # Logged-in app. Existing frontend templates / design are reused as-is.
    path("main/", auth_views.main_page, name="home"),
    path("main/", auth_views.main_page, name="index"),
    path("recommend/", auth_views.recommend_page, name="recommend"),
    path("friends/", auth_views.friends_page, name="friends"),
    path("profile/", auth_views.profile_page, name="profile"),
    path("diary/", auth_views.diary_page, name="diary"),
]

# Keep legacy recommendation/profile endpoints when they already exist in the project.
_optional_legacy_routes = [
    ("recommend/home/", "recommend_home", "recommend_home"),
    ("recommend/custom/", "recommend_custom", "recommend_custom"),
    ("local/", "local_consumption", "local_consumption"),
    ("profile/clear/", "clear_profile", "profile_clear"),
    ("api/check-nickname/", "check_nickname", "check_nickname"),
]
for route, attr, name in _optional_legacy_routes:
    view = getattr(legacy_views, attr, None)
    if view is not None:
        urlpatterns.append(path(route, view, name=name))

# Preserve optional recommendation API modules without making them a hard dependency
# for the newer frontend-only project variant.
try:
    from .profile_demo import demo_recommendations
except ImportError:
    demo_recommendations = None
if demo_recommendations is not None:
    urlpatterns.append(path("demo-api/recommendations/", demo_recommendations, name="profile_demo_recommendations"))

try:
    from .live_recommendations import live_recommendations
except ImportError:
    live_recommendations = None
if live_recommendations is not None:
    urlpatterns.append(path("api/live-recommendations/", live_recommendations, name="live_recommendations"))
