from django.contrib.auth.hashers import check_password, make_password
from django.test import TestCase
from django.urls import reverse

from .models import Member


class MemberAuthFlowTests(TestCase):
    def signup_payload(self, **overrides):
        payload = {
            "name": "테스트사용자",
            "nickname": "움직이자",
            "password": "MovePass12!",
            "password_confirm": "MovePass12!",
            "address": "서울특별시 관악구",
        }
        payload.update(overrides)
        return payload

    def create_member(self, nickname="움직이자", password="MovePass12!"):
        return Member.objects.create(
            name="테스트사용자",
            nickname=nickname,
            password_hash=make_password(password),
            address="서울특별시 관악구",
        )

    def test_signup_success_and_password_is_hashed(self):
        response = self.client.post(reverse("signup"), self.signup_payload())
        self.assertRedirects(response, reverse("login"), fetch_redirect_response=False)
        member = Member.objects.get(nickname="움직이자")
        self.assertNotEqual(member.password_hash, "MovePass12!")
        self.assertTrue(check_password("MovePass12!", member.password_hash))

    def test_nickname_duplicate_check(self):
        self.create_member()
        response = self.client.get(reverse("check_member_nickname"), {"nickname": "움직이자"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"available": False})

    def test_password_rules(self):
        invalid_cases = [
            ("short", "Ab1!", "Ab1!"),
            ("space", "Move Pass12!", "Move Pass12!"),
            ("hangul", "운동Move12!", "운동Move12!"),
            ("numbers_only", "12345678", "12345678"),
            ("repeat_four", "Movaaaa12!", "Movaaaa12!"),
            ("same_as_nickname", "MovePass12!", "MovePass12!"),
            ("confirm_mismatch", "GoodPass12!", "OtherPass12!"),
        ]
        for label, password, confirm in invalid_cases:
            with self.subTest(label=label):
                payload = self.signup_payload(
                    nickname="MovePass12!" if label == "same_as_nickname" else f"user_{label}",
                    password=password,
                    password_confirm=confirm,
                )
                response = self.client.post(reverse("signup"), payload)
                self.assertEqual(response.status_code, 200)
                self.assertFalse(Member.objects.filter(nickname=payload["nickname"]).exists())

    def test_login_success_stores_required_session_values(self):
        member = self.create_member()
        response = self.client.post(reverse("login"), {"nickname": member.nickname, "password": "MovePass12!"})
        self.assertRedirects(response, reverse("home"), fetch_redirect_response=False)
        session = self.client.session
        self.assertEqual(session["member_id"], member.pk)
        self.assertEqual(session["member_nickname"], member.nickname)

    def test_bad_login_uses_same_error_for_unknown_user_and_wrong_password(self):
        self.create_member()
        missing = self.client.post(reverse("login"), {"nickname": "없는닉네임", "password": "WrongPass12!"})
        wrong = self.client.post(reverse("login"), {"nickname": "움직이자", "password": "WrongPass12!"})
        message = "아이디 또는 비밀번호 오류입니다."
        self.assertContains(missing, message)
        self.assertContains(wrong, message)

    def test_main_redirects_to_login_without_member_session(self):
        response = self.client.get(reverse("home"))
        self.assertRedirects(response, reverse("login"), fetch_redirect_response=False)


    def test_guest_start_allows_main_without_member_account(self):
        response = self.client.post(reverse("guest_start"))
        self.assertRedirects(response, reverse("home"), fetch_redirect_response=False)
        self.assertTrue(self.client.session.get("guest_mode"))

        room = self.client.get(reverse("home"))
        self.assertEqual(room.status_code, 200)
        self.assertContains(room, "MY ROOM")
        self.assertContains(room, "GUEST ROOM")

    def test_guest_mode_unlocks_all_app_pages(self):
        self.client.post(reverse("guest_start"))
        for route_name in ["home", "recommend", "friends", "profile", "diary"]:
            with self.subTest(route=route_name):
                response = self.client.get(reverse(route_name))
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'data-is-guest="1"')

    def test_guest_profile_page_is_editable_frontend(self):
        self.client.post(reverse("guest_start"))
        response = self.client.get(reverse("profile"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'id="profileForm"')
        self.assertContains(response, '게스트 프로필 수정')

    def test_direct_app_pages_still_require_member_or_guest_session(self):
        for route_name in ["home", "recommend", "friends", "profile", "diary"]:
            with self.subTest(route=route_name):
                response = self.client.get(reverse(route_name))
                self.assertRedirects(response, reverse("login"), fetch_redirect_response=False)

    def test_logout_clears_session_and_redirects_to_opening(self):
        member = self.create_member()
        session = self.client.session
        session["member_id"] = member.pk
        session["member_nickname"] = member.nickname
        session.save()

        response = self.client.post(reverse("logout"))
        self.assertRedirects(response, reverse("welcome"), fetch_redirect_response=False)
        self.assertNotIn("member_id", self.client.session)
        self.assertNotIn("member_nickname", self.client.session)

    def test_main_displays_logged_in_nickname_and_address(self):
        member = self.create_member()
        session = self.client.session
        session["member_id"] = member.pk
        session["member_nickname"] = member.nickname
        session.save()
        response = self.client.get(reverse("home"))
        self.assertContains(response, member.nickname)
        self.assertContains(response, member.address)
