# 우심운까 PAGE1 + WOW 기능 통합본

이 패키지는 두 입력본을 아래 원칙으로 합쳤습니다.

- **디자인/UI/캐릭터/모션:** PAGE1 파일을 기준본으로 유지
- **기능/API/서비스 레이어:** WOW 파일의 Django backend를 통합
- **API Contract:** 기존 `/api/*` 구조 유지
- **Mock/LIVE 구분:** 단독 `frontend/dist/index.html`은 Mock 검증용, Django로 실행하면 LIVE backend 사용

## 실행

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py runserver 127.0.0.1:8000
```

브라우저에서 `http://127.0.0.1:8000/` 접속.

로그인 버튼은 현재 실제 OAuth가 아니라 WOW backend에 이미 있던 DEV/QA 세션을 연결한 `/login` 화면으로 이동합니다.

## 현재 실제로 동작하는 통합 범위

- PAGE1 대한민국 지도 / 지역 클릭 팝업
- 지역 마스코트 + 전국 1위 캐릭터 직접 모션
- 일별 지역 활동 랭킹 snapshot 비교
- 로그인 사용자 주소지 기반 `우리 동네는 지금`
- 인증 후 친구 랭킹
- 친구 코드 추가
- 운동 완료 기록 API

## 아직 PENDING_DATA

- 공식 공공데이터 랭킹
- 시설 조회
- 추천/Execution Score
- Pipeline Dashboard

위 영역은 WOW 원본과 동일하게 M3 데이터 연결 전까지 `PENDING_DATA`로 유지합니다.
