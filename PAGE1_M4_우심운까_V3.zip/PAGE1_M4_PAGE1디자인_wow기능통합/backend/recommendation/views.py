from rest_framework.views import APIView

from common.responses import pending_data


class RecommendationView(APIView):
    """POST /api/recommendations — Execution Score는 시설/날씨/대기질(M3) 데이터가
    있어야 계산 가능하므로, M3 연결 전까지 501 PENDING_DATA로 응답한다.
    """

    authentication_classes: list = []
    permission_classes: list = []

    def post(self, request):
        return pending_data(
            "추천 Engine은 시설/날씨/대기질 데이터(M3) 연결 후 제공됩니다. "
            "services/repositories/facility_repo.py의 Provider 구현체를 "
            "추가하면 활성화됩니다."
        )
