# 우심운까 M2 Backend (데이터 파이프라인 제외 버전)

설계 배경: [`../백엔드_설계.md`](../백엔드_설계.md)
API 계약: [`../PAGE1_M4_우심운까_지역팝업_마스코트추가/docs/API.md`](../PAGE1_M4_우심운까_지역팝업_마스코트추가/docs/API.md)

## 지금 이 상태가 뭔지

- **DB 연결 없음.** `services/repositories/`의 In-Memory 구현체가 데이터를 낸다.
- **M3(Data Pipeline) 없음.** 시설/추천/공식랭킹 관련 API는 라우트만 있고 `501 PENDING_DATA`로 응답한다.
- 서버를 재시작하면 친구 추가/운동완료 기록은 초기화된다 (프로세스 메모리에만 저장).

## 실행

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py runserver 127.0.0.1:8000
```

## PAGE1_M4 프론트와 붙여보기

`PAGE1_M4_우심운까_지역팝업_마스코트추가/dist/index.html`이 로드되기 전에 아래 두 전역값을 설정하면 Mock 대신 이 backend를 사용한다.

```html
<script>
  window.USIMUNKKA_USE_MOCK = false;
  window.USIMUNKKA_API_BASE = "http://127.0.0.1:8000";
</script>
```

친구 랭킹 등 인증이 필요한 화면을 테스트하려면 실제 로그인 페이지가 아직 없으므로, 개발자 도구 콘솔에서 세션 쿠키를 먼저 발급한다.

```js
fetch("http://127.0.0.1:8000/api/auth/dev-login", {
  method: "POST",
  credentials: "include",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ user_id: 7 }),
}).then(() => location.reload());
```

`/api/auth/dev-login`은 `docs/API.md` 정식 계약이 아닌 개발/QA 전용 엔드포인트다 (`users/views.py` 주석 참고). 실제 로그인은 이후 별도 구현한다.

## 빠른 동작 확인 (curl)

```bash
curl http://127.0.0.1:8000/api/rankings
curl -i http://127.0.0.1:8000/api/users/me                     # 401 (미인증)
curl -c c.txt -X POST http://127.0.0.1:8000/api/auth/dev-login \
  -H "Content-Type: application/json" -d '{"user_id":7}'
curl -b c.txt http://127.0.0.1:8000/api/friends/ranking
curl -b c.txt -X POST http://127.0.0.1:8000/api/friends \
  -H "Content-Type: application/json" -d '{"friend_code":"USIM-HANEUL"}'
curl -i http://127.0.0.1:8000/api/facilities                    # 501 PENDING_DATA
```

## 폴더 구조

```
backend/
├── config/            Django settings/urls
├── common/            dev_session(쿠키 기반 임시 로그인), responses(PENDING_DATA 헬퍼)
├── services/
│   ├── dto.py          도메인 데이터 모양 (dataclass)
│   ├── exceptions.py    ServiceError 계열
│   └── repositories/    Repository — 지금은 전부 In-Memory
│       ├── user_repo.py / friendship_repo.py / activity_repo.py   (구현됨)
│       ├── ranking_repo.py   ActivityRanking(구현) / OfficialRanking(Interface만)
│       ├── facility_repo.py  Facility/Weather/AirQuality (Interface만, 미구현)
│       └── fixtures/         In-Memory 시드 데이터
├── rankings/    GET /api/rankings
├── users/       GET /api/users/me, POST /api/auth/dev-login·logout
├── friends/     GET /api/friends/ranking, POST /api/friends
├── activities/  POST /api/activities/complete
├── facilities/       GET /api/facilities(/{id})       → 501 PENDING_DATA
├── recommendation/   POST /api/recommendations        → 501 PENDING_DATA
└── pipeline/         GET /api/admin/pipeline          → 501 PENDING_DATA
```

## 다음 단계 (지금 안 함)

- 실제 DB 연동: `services/repositories/*`의 In-Memory 구현체를 MySQL 기반으로 교체
- 실제 로그인(OAuth 등): `common/dev_session.py` → 정식 인증으로 교체
- M3 연결: `services/repositories/ranking_repo.py`의 `OfficialRankingRepository`, `facility_repo.py`의 `FacilityRepository`/`WeatherProvider`/`AirQualityProvider`를 구현하는 클래스 추가

순서와 세부 내용은 [`../백엔드_설계.md`](../백엔드_설계.md) 10번 참고.
