from rest_framework.views import APIView

from common.responses import pending_data

_MESSAGE = (
    "시설 데이터는 M3 Data Pipeline 연결 후 제공됩니다. "
    "services/repositories/facility_repo.py의 FacilityRepository 구현체를 "
    "추가하면 활성화됩니다."
)


class FacilityListView(APIView):
    """GET /api/facilities — M3 연결 전까지 501 PENDING_DATA."""

    authentication_classes: list = []
    permission_classes: list = []

    def get(self, request):
        return pending_data(_MESSAGE)


class FacilityDetailView(APIView):
    """GET /api/facilities/{id} — M3 연결 전까지 501 PENDING_DATA."""

    authentication_classes: list = []
    permission_classes: list = []

    def get(self, request, facility_id: int):
        return pending_data(_MESSAGE)
