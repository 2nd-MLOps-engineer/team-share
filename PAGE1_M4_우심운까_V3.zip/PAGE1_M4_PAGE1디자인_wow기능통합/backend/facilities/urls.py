from django.urls import path

from facilities.views import FacilityDetailView, FacilityListView

urlpatterns = [
    path("facilities", FacilityListView.as_view(), name="facilities-list"),
    path("facilities/<int:facility_id>", FacilityDetailView.as_view(), name="facilities-detail"),
]
