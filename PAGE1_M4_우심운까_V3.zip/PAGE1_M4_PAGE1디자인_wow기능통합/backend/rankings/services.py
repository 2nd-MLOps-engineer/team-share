"""지역 랭킹 조립 로직.

PAGE1_M4 프론트의 dist/services/rankingApi.js `buildActivityPayload()`와
동일한 계산 규칙을 서버 쪽으로 옮긴 것이다. 프론트가 Mock 모드에서 하던
is_hot/state/rank_change 계산을 백엔드가 대신 계산해서 내려준다.
"""
from __future__ import annotations

from services.repositories.ranking_repo import activity_ranking_repository

_HOT_SCORE_CHANGE_RATE = 0.035
_HOT_RANK_CHANGE = 5


def _region_state(national_rank: int, is_hot: bool, rank_change: int) -> str:
    if national_rank <= 3:
        return "top"
    if is_hot:
        return "hot"
    if rank_change > 0:
        return "rising"
    if rank_change < 0:
        return "falling"
    return ""


def _build_activity_rows(latest: dict | None, previous: dict | None) -> list[dict]:
    if latest is None:
        return []
    prev_by_province = {row["province"]: row for row in (previous or {}).get("regions", [])}
    rows = []
    for row in latest["regions"]:
        prev = prev_by_province.get(row["province"])
        previous_rank = prev["national_rank"] if prev else row["national_rank"]
        rank_change = previous_rank - row["national_rank"]
        score_change_rate = 0.0
        if prev and prev.get("score"):
            score_change_rate = (row["score"] - prev["score"]) / prev["score"]
        is_hot = score_change_rate >= _HOT_SCORE_CHANGE_RATE or rank_change >= _HOT_RANK_CHANGE
        rows.append({
            **row,
            "previous_rank": previous_rank,
            "rank_change": rank_change,
            "is_hot": is_hot,
            "state": _region_state(row["national_rank"], is_hot, rank_change),
            "score_change_rate": score_change_rate,
        })
    return rows


def build_rankings_payload() -> dict:
    latest, previous = activity_ranking_repository.latest_two_snapshots()
    return {
        "snapshot_date": latest["date"] if latest else None,
        "window_days": latest["window_days"] if latest else 7,
        "activity": _build_activity_rows(latest, previous),
        # 공식 공공데이터 랭킹은 M3 연결 전까지 비워둔다. 빈 배열은 "데이터 없음"이
        # 아니라 "아직 준비 안 됨"이므로 official_status로 명시한다.
        "official": [],
        "official_status": "PENDING_DATA",
    }
