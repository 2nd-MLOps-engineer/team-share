from rest_framework.response import Response
from rest_framework.views import APIView

from rankings.services import build_rankings_payload


class RankingsView(APIView):
    """GET /api/rankings — 비로그인 사용자도 조회 가능 (docs/API.md 원칙)."""

    authentication_classes: list = []
    permission_classes: list = []

    def get(self, request):
        return Response(build_rankings_payload())
