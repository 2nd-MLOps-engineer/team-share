"""서비스 계층 데이터 구조.

여기 정의된 dataclass는 DB 모델이 아니다. Repository가 반환하는 값의 "형태"만
고정해서, 나중에 In-Memory 구현체를 MySQL 기반 구현체로 바꿔도
Service/View 코드가 받는 데이터 모양이 그대로 유지되도록 한다.
(백엔드_설계.md 4번 "나중에 M3만 갈아끼우는 구조" 참고)
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class User:
    id: int
    nickname: str
    friend_code: str
    activity_score: int
    previous_activity_score: int
    color: str
    province: str | None = None
    region_code: str | None = None
    region_name: str | None = None
    address: str | None = None


@dataclass(frozen=True)
class RegionActivitySnapshot:
    """우심운까 사용자 활동 기준 지역 랭킹 (서비스 자체 데이터, M3 불필요)."""

    date: str
    window_days: int
    province: str
    region_name: str
    national_rank: int
    regional_rank: int
    score: int
    metrics: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class OfficialRankingSnapshot:
    """공식 공공데이터 기준 지역 랭킹. M3 연결 전까지 어떤 구현체도 없다."""

    province: str
    region_name: str
    national_rank: int
    regional_rank: int
    score: int
    reference_period: str
    metrics: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class ActivityLogEntry:
    id: int
    user_id: int
    sport_type: str
    duration_minutes: int
    score: int
    created_at: str
    facility_id: int | None = None


@dataclass(frozen=True)
class Facility:
    """M3가 시설 MASTER 테이블을 채운 뒤 실제로 채워진다. 지금은 정의만 한다."""

    id: int
    name: str
    sido: str
    sigungu: str
    latitude: float
    longitude: float
    indoor_outdoor: str


@dataclass(frozen=True)
class WeatherSnapshot:
    observed_at: str
    temperature_c: float
    precipitation_mm: float


@dataclass(frozen=True)
class AirQualitySnapshot:
    observed_at: str
    pm10: int
    pm25: int
