class ServiceError(Exception):
    status_code = 400


class UnauthenticatedError(ServiceError):
    status_code = 401


class NotFoundError(ServiceError):
    status_code = 404


class PendingDataError(ServiceError):
    """M3 Data Pipeline 연결 전까지는 응답할 수 없는 기능에서 발생시킨다.

    없는 데이터를 정상 데이터처럼 보이게 하지 않는다는 원칙(지침서.md RULE 9/10,
    55번)에 따라, "결과 없음"이 아니라 "아직 준비되지 않음"을 명시적으로 표현한다.
    """

    status_code = 501
