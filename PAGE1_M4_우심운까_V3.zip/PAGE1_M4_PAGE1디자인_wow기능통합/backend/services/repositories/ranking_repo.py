"""지역 랭킹 Repository.

두 종류를 명확히 분리한다 (지침서.md 10번, 백엔드_설계.md 3번):

- ActivityRankingRepository : 우심운까 사용자 활동 기준. 서비스 자체 데이터라
  M3 없이 지금 구현 가능. 지금은 fixture 3일치를 사용하고,
  DB 연동 단계에서 activity_log 일별 집계로 교체된다.
- OfficialRankingRepository : 공식 공공데이터(KSPO 등) 기준. M3가 데이터를
  적재하기 전까지는 어떤 구현체도 존재하지 않는다. 여기서는 "나중에 이 모양의
  데이터를 돌려주면 된다"는 계약(Protocol)만 정의해둔다.
"""
from __future__ import annotations

from typing import Protocol

from services.dto import OfficialRankingSnapshot
from services.repositories.fixtures.activity_data import SEED_ACTIVITY_DAILY


class InMemoryActivityRankingRepository:
    def __init__(self) -> None:
        self._history = sorted(SEED_ACTIVITY_DAILY, key=lambda snapshot: snapshot["date"])

    def latest_two_snapshots(self) -> tuple[dict | None, dict | None]:
        latest = self._history[-1] if self._history else None
        previous = self._history[-2] if len(self._history) >= 2 else None
        return latest, previous


activity_ranking_repository = InMemoryActivityRankingRepository()


class OfficialRankingRepository(Protocol):
    """M3 연결 지점. 지금은 구현체가 없다 (rankings/services.py에서
    PENDING_DATA로 명시적으로 응답한다). M3가 region_statistics 등을 채운 뒤
    이 Protocol을 구현하는 MySQL 기반 클래스를 추가하면 된다.
    """

    def list_latest(self) -> list[OfficialRankingSnapshot]: ...

    def get_latest(self, region_code: str) -> OfficialRankingSnapshot | None: ...
