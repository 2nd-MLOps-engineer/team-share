"""운동완료 기록(activity_log) Repository — In-Memory 구현체.

주의: 지금은 저장만 하고, 지역/친구 랭킹에는 자동 반영되지 않는다.
랭킹은 여전히 fixtures/activity_data.py의 고정 snapshot을 사용한다.
'운동완료 → 점수 → 랭킹 변화' 연결은 DB 연동 단계에서 함께 구현한다
(지침서.md 29번 참고).
"""
from __future__ import annotations

import itertools
import threading
from datetime import datetime, timezone

from services.dto import ActivityLogEntry


class InMemoryActivityLogRepository:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._logs: list[ActivityLogEntry] = []
        self._id_seq = itertools.count(1)

    def add(
        self,
        *,
        user_id: int,
        sport_type: str,
        duration_minutes: int,
        score: int,
        facility_id: int | None = None,
    ) -> ActivityLogEntry:
        with self._lock:
            entry = ActivityLogEntry(
                id=next(self._id_seq),
                user_id=user_id,
                sport_type=sport_type,
                duration_minutes=duration_minutes,
                score=score,
                facility_id=facility_id,
                created_at=datetime.now(timezone.utc).isoformat(),
            )
            self._logs.append(entry)
            return entry

    def list_for_user(self, user_id: int) -> list[ActivityLogEntry]:
        return [log for log in self._logs if log.user_id == user_id]


activity_log_repository = InMemoryActivityLogRepository()
