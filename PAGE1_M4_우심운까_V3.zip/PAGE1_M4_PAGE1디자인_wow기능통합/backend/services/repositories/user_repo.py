"""User Repository — 지금은 In-Memory, 나중에 DB 구현체로 교체 대상.

주의: friendship_repo.py와 마찬가지로 이 Repository도 M3(Data Pipeline)와는
무관하다. User/Friendship은 원래 서비스 자체 데이터(SERVICE 영역)이며,
'디비 연결을 아직 하지 않았다'는 이번 단계의 결정 때문에 In-Memory로 둔 것뿐이다.
"""
from __future__ import annotations

from services.dto import User
from services.repositories.fixtures.activity_data import SEED_USERS


class InMemoryUserRepository:
    def __init__(self) -> None:
        self._users: dict[int, User] = {user.id: user for user in SEED_USERS}

    def get(self, user_id: int) -> User | None:
        return self._users.get(user_id)

    def find_by_friend_code(self, code: str) -> User | None:
        normalized = code.strip().upper()
        for user in self._users.values():
            if user.friend_code.upper() == normalized:
                return user
        return None

    def all(self) -> list[User]:
        return list(self._users.values())


user_repository = InMemoryUserRepository()
