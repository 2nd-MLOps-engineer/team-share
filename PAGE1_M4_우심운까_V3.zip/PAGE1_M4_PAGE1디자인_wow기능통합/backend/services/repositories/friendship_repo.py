"""Friendship Repository — In-Memory 구현체.

주의: 프로세스 메모리에만 저장되므로 서버를 재시작하면 친구 추가 내역이
초기화된다. DB 연동 단계에서 MySQL 기반 구현체로 교체될 때까지의 임시 구조다.
"""
from __future__ import annotations

import threading

from services.repositories.fixtures.activity_data import SEED_FRIENDSHIPS


class InMemoryFriendshipRepository:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._friendships: dict[str, list[int]] = {
            key: list(values) for key, values in SEED_FRIENDSHIPS.items()
        }

    def friends_of(self, user_id: int) -> list[int]:
        return list(self._friendships.get(str(user_id), []))

    def add(self, user_id: int, friend_id: int) -> bool:
        """이미 친구였다면 False, 새로 추가됐다면 True."""
        with self._lock:
            key = str(user_id)
            existing = self._friendships.setdefault(key, [])
            if friend_id in existing:
                return False
            existing.append(friend_id)
            return True


friendship_repository = InMemoryFriendshipRepository()
