"""M3 연결 지점 (시설 / 날씨 / 대기질).

지금은 구현체가 전혀 없다. M3가 raw_kspo_facility 등을 MASTER 테이블로
정규화하고, 기상청/에어코리아 연동이 준비되면 아래 Protocol을 구현하는
클래스를 추가한다. facilities/recommendation 앱은 그 구현체가 생기기
전까지 PendingDataError를 던진다.
"""
from __future__ import annotations

from typing import Protocol

from services.dto import AirQualitySnapshot, Facility, WeatherSnapshot


class FacilityRepository(Protocol):
    def search_nearby(
        self, lat: float, lng: float, sport: str | None, radius_km: float
    ) -> list[Facility]: ...

    def get(self, facility_id: int) -> Facility | None: ...


class WeatherProvider(Protocol):
    def get_current(self, lat: float, lng: float) -> WeatherSnapshot | None: ...


class AirQualityProvider(Protocol):
    def get_current(self, lat: float, lng: float) -> AirQualitySnapshot | None: ...
