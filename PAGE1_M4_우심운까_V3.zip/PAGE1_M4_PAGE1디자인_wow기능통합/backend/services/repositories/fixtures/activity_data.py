"""In-Memory 임시 데이터.

PAGE1_M4_우심운까_지역팝업_마스코트추가/dist/mock/rankings.js 와 동일한 스키마를
그대로 옮겨온 것이다. M3 Data Pipeline이 없는 지금 단계에서 서비스 자체 데이터
(User/Friendship/활동지수 랭킹)를 돌려보기 위한 fixture일 뿐,
실제 서비스 데이터가 아니다 (지침서.md 56번: Mock과 Live 구분 원칙).

이후 DB 연동 단계에서는 이 파일 대신 실제 Repository 구현체가 사용된다.
"""
from __future__ import annotations

from services.dto import User

SEED_USERS: list[User] = [
    User(
        id=7, nickname="나", friend_code="USIM-7K29",
        region_code="11620", region_name="관악구", province="서울특별시",
        address="서울특별시 관악구 봉천동",
        activity_score=4180, previous_activity_score=3920, color="#c8ff3d",
    ),
    User(
        id=2, nickname="민수", friend_code="USIM-MINSU",
        region_name="강남구", province="서울특별시",
        address="서울특별시 강남구 역삼동",
        activity_score=4820, previous_activity_score=4700, color="#ffd75f",
    ),
    User(
        id=3, nickname="지훈", friend_code="USIM-JIHUN",
        region_name="마포구", province="서울특별시",
        address="서울특별시 마포구 서교동",
        activity_score=4510, previous_activity_score=4520, color="#74caff",
    ),
    User(
        id=4, nickname="서준", friend_code="USIM-SEOJUN",
        region_name="성동구", province="서울특별시",
        address="서울특별시 성동구 성수동",
        activity_score=3940, previous_activity_score=4010, color="#ff9b76",
    ),
    User(
        id=5, nickname="하늘", friend_code="USIM-HANEUL",
        region_name="송파구", province="서울특별시",
        address="서울특별시 송파구 잠실동",
        activity_score=3610, previous_activity_score=3520, color="#d2b0ff",
    ),
]

SEED_FRIENDSHIPS: dict[str, list[int]] = {
    "7": [2, 3],
    "2": [7, 3],
    "3": [7, 2],
    "4": [7],
    "5": [7],
}

_REGION_ORDER = [
    ("서울특별시", "관악구", {"걷기": 12, "생활체육": 8, "운동환경": 21}, 5),
    ("경기도", "수원시", {"걷기": 3, "생활체육": 1, "운동환경": 6}, 1),
    ("부산광역시", "해운대구", {"걷기": 7, "생활체육": 2, "운동환경": 4}, 1),
    ("대전광역시", "유성구", {"걷기": 9, "생활체육": 3, "운동환경": 5}, 1),
    ("강원특별자치도", "춘천시", {"걷기": 4, "생활체육": 11, "운동환경": 7}, 1),
    ("충청북도", "청주시", {"걷기": 10, "생활체육": 6, "운동환경": 12}, 1),
    ("인천광역시", "연수구", {"걷기": 8, "생활체육": 7, "운동환경": 13}, 1),
    ("대구광역시", "수성구", {"걷기": 13, "생활체육": 9, "운동환경": 11}, 1),
    ("전북특별자치도", "전주시", {"걷기": 14, "생활체육": 9, "운동환경": 18}, 1),
    ("울산광역시", "남구", {"걷기": 17, "생활체육": 12, "운동환경": 9}, 1),
    ("세종특별자치시", "세종시", {"걷기": 6, "생활체육": 15, "운동환경": 10}, 1),
    ("충청남도", "천안시", {"걷기": 16, "생활체육": 14, "운동환경": 15}, 1),
    ("경상북도", "포항시", {"걷기": 11, "생활체육": 10, "운동환경": 8}, 1),
    ("경상남도", "창원시", {"걷기": 18, "생활체육": 13, "운동환경": 16}, 1),
    ("전남광주통합특별시", "광주권", {"걷기": 15, "생활체육": 17, "운동환경": 19}, 1),
    ("제주특별자치도", "제주시", {"걷기": 2, "생활체육": 7, "운동환경": 3}, 1),
]

# (date, window_days, [national_rank, score] per region in _REGION_ORDER)
_DAILY_RANKS = [
    ("2026-09-09", 7, [27, 2, 8, 6, 17, 10, 13, 12, 11, 18, 11, 20, 16, 16, 21, 10]),
    ("2026-09-10", 7, [25, 3, 7, 4, 18, 9, 11, 13, 10, 16, 12, 19, 14, 17, 20, 8]),
    ("2026-09-11", 7, [17, 1, 2, 3, 8, 6, 7, 10, 11, 12, 13, 14, 9, 15, 16, 5]),
]
_DAILY_SCORES = [
    [8000, 9407, 9224, 9011, 8478, 8600, 8537, 8314, 8211, 8168, 8070, 7957, 8384, 7891, 7768, 8760],
    [8200, 9607, 9424, 9211, 8678, 8800, 8737, 8514, 8411, 8368, 8270, 8157, 8584, 8091, 7968, 8960],
    [8420, 9827, 9644, 9431, 8898, 9020, 8957, 8734, 8631, 8588, 8490, 8377, 8804, 8311, 8188, 9180],
]


def _build_activity_daily() -> list[dict]:
    days = []
    for day_index, (date, window_days, ranks) in enumerate(_DAILY_RANKS):
        regions = []
        for region_index, (province, region_name, metrics, regional_rank) in enumerate(_REGION_ORDER):
            regions.append({
                "province": province,
                "region_name": region_name,
                "national_rank": ranks[region_index],
                "regional_rank": regional_rank,
                "score": _DAILY_SCORES[day_index][region_index],
                "metrics": dict(metrics),
            })
        days.append({"date": date, "window_days": window_days, "regions": regions})
    return days


SEED_ACTIVITY_DAILY: list[dict] = _build_activity_daily()
