from __future__ import annotations

from services.dto import User
from services.exceptions import NotFoundError, ServiceError, UnauthenticatedError
from services.repositories.friendship_repo import friendship_repository
from services.repositories.user_repo import user_repository


def require_current_user(user_id: int | None) -> User:
    if user_id is None:
        raise UnauthenticatedError("로그인이 필요합니다.")
    user = user_repository.get(user_id)
    if user is None:
        raise UnauthenticatedError("로그인이 필요합니다.")
    return user


def build_friend_ranking(me: User) -> list[dict]:
    ids = {me.id, *friendship_repository.friends_of(me.id)}
    members = [user for user in (user_repository.get(i) for i in ids) if user is not None]
    current = sorted(members, key=lambda user: user.activity_score, reverse=True)
    previous = sorted(members, key=lambda user: user.previous_activity_score, reverse=True)
    previous_rank = {user.id: index + 1 for index, user in enumerate(previous)}

    ranking = []
    for index, user in enumerate(current):
        rank = index + 1
        ranking.append({
            "rank": rank,
            "user_id": user.id,
            "nickname": user.nickname,
            "activity_score": user.activity_score,
            "rank_change": previous_rank.get(user.id, rank) - rank,
            "is_me": user.id == me.id,
            "color": user.color,
        })
    return ranking


def add_friend(me: User, friend_code: str) -> tuple[User, bool]:
    code = (friend_code or "").strip()
    if not code:
        raise ServiceError("친구 코드를 입력해 주세요.")
    friend = user_repository.find_by_friend_code(code)
    if friend is None:
        raise NotFoundError("해당 친구 코드를 찾지 못했어요.")
    if friend.id == me.id:
        raise ServiceError("내 친구 코드는 등록할 수 없어요.")
    newly_added = friendship_repository.add(me.id, friend.id)
    return friend, not newly_added
