from django.urls import path

from friends.views import FriendAddView, FriendRankingView

urlpatterns = [
    path("friends/ranking", FriendRankingView.as_view(), name="friends-ranking"),
    path("friends", FriendAddView.as_view(), name="friends-add"),
]
