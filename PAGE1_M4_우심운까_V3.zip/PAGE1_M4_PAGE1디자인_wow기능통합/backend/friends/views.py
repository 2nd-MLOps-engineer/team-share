from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from common.dev_session import read_user_id
from friends.services import add_friend, build_friend_ranking, require_current_user
from services.exceptions import ServiceError


class FriendRankingView(APIView):
    """GET /api/friends/ranking — 인증 필요 (docs/API.md)."""

    authentication_classes: list = []
    permission_classes: list = []

    def get(self, request):
        try:
            me = require_current_user(read_user_id(request))
        except ServiceError as error:
            return Response(status=error.status_code)
        return Response({"ranking": build_friend_ranking(me)})


class FriendAddView(APIView):
    """POST /api/friends — 인증 필요 (docs/API.md)."""

    authentication_classes: list = []
    permission_classes: list = []

    def post(self, request):
        try:
            me = require_current_user(read_user_id(request))
        except ServiceError as error:
            return Response(status=error.status_code)
        try:
            friend, already_exists = add_friend(me, request.data.get("friend_code"))
        except ServiceError as error:
            return Response({"detail": str(error)}, status=error.status_code)
        return Response({
            "friend": {
                "id": friend.id,
                "nickname": friend.nickname,
                "friend_code": friend.friend_code,
            },
            "already_exists": already_exists,
        }, status=status.HTTP_200_OK)
