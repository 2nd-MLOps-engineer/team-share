"""PAGE1 frontend integration for local/dev use.

The frontend files are the PAGE1 design package. API calls run in LIVE mode when
served through this Django app so the WOW backend functionality is exercised.
The original frontend/dist/index.html remains unchanged for standalone/mock use.
"""
from __future__ import annotations

import html
import mimetypes
from pathlib import Path
from urllib.parse import quote

from django.conf import settings
from django.http import FileResponse, Http404, HttpResponse

from services.repositories.user_repo import user_repository


def _dist_root() -> Path:
    return Path(settings.FRONTEND_DIST).resolve()


def frontend_index(request):
    index_path = _dist_root() / "index.html"
    if not index_path.exists():
        raise Http404("PAGE1 frontend index.html not found")
    source = index_path.read_text(encoding="utf-8")
    live_bootstrap = """<script>
  // Django 통합 실행 시 WOW backend API를 사용한다.
  globalThis.USIMUNKKA_USE_MOCK = false;
  globalThis.USIMUNKKA_API_BASE = "";
</script>"""
    source = source.replace("</head>", f"  {live_bootstrap}\n</head>", 1)
    return HttpResponse(source, content_type="text/html; charset=utf-8")


def frontend_asset(request, path: str):
    root = _dist_root()
    candidate = (root / path).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise Http404("Invalid frontend path") from exc
    if not candidate.is_file():
        raise Http404("Frontend asset not found")
    content_type, _ = mimetypes.guess_type(candidate.name)
    return FileResponse(candidate.open("rb"), content_type=content_type or "application/octet-stream")


def login_page(request):
    """DEV/QA login page.

    Production auth is intentionally not invented here. This page only connects
    the existing /api/auth/dev-login endpoint to the PAGE1 login button so the
    merged package can be functionally tested end-to-end.
    """
    next_url = request.GET.get("next") or "/"
    safe_next = quote(next_url, safe="/?:=&%#")
    cards = []
    for user in user_repository.all():
        cards.append(
            f'<button class="user-card" data-user-id="{user.id}" type="button">'
            f'<span class="avatar">{html.escape(user.nickname[:1])}</span>'
            f'<span><strong>{html.escape(user.nickname)}</strong>'
            f'<small>{html.escape(user.province)} · {html.escape(user.region_name)}</small></span>'
            f'<em>{html.escape(user.friend_code)}</em></button>'
        )
    cards_html = "".join(cards)
    page = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>우심운까 DEV 로그인</title>
<style>
*{{box-sizing:border-box}}body{{margin:0;min-height:100vh;display:grid;place-items:center;font-family:Arial,'Apple SD Gothic Neo',sans-serif;color:#544f69;background:radial-gradient(circle at 20% 15%,#f7ddf0 0,transparent 34%),radial-gradient(circle at 80% 20%,#dbefff 0,transparent 36%),linear-gradient(145deg,#faf6ff,#eef7ff)}}
.login{{width:min(560px,calc(100% - 32px));padding:30px;border:1px solid rgba(155,126,196,.18);border-radius:28px;background:rgba(255,255,255,.72);box-shadow:0 24px 70px rgba(116,93,158,.15);backdrop-filter:blur(16px)}}
.kicker{{margin:0;color:#9d7fc0;font-size:.72rem;font-weight:900;letter-spacing:.12em}}h1{{margin:7px 0 8px;font-size:1.8rem;color:#5e5574}}.desc{{margin:0 0 20px;color:#8c86a0;font-size:.88rem;line-height:1.6}}.users{{display:grid;gap:9px}}.user-card{{display:grid;grid-template-columns:44px 1fr auto;align-items:center;gap:11px;width:100%;padding:12px;border:1px solid rgba(155,126,196,.15);border-radius:16px;background:rgba(255,255,255,.78);text-align:left;cursor:pointer;transition:.18s}}.user-card:hover{{transform:translateY(-2px);border-color:#bda5dd;box-shadow:0 10px 24px rgba(118,95,157,.11)}}.avatar{{display:grid;place-items:center;width:42px;height:42px;border-radius:14px;background:linear-gradient(145deg,#e9ddff,#d9f0ff);font-weight:900;color:#725b9a}}.user-card strong,.user-card small{{display:block}}.user-card small{{margin-top:3px;color:#9690a8}}.user-card em{{font-size:.7rem;color:#a394b7;font-style:normal}}.notice{{margin:17px 0 0;padding:11px 13px;border-radius:14px;background:#fff8dd;color:#8c7641;font-size:.75rem;line-height:1.5}}
</style></head><body><main class="login"><p class="kicker">DEV / QA LOGIN</p><h1>우심운까 로그인</h1><p class="desc">통합 기능 확인용 임시 로그인입니다. 실제 OAuth/회원 DB 로그인으로 대체될 영역이에요.</p><div class="users">{cards_html}</div><p class="notice">⚠ 이 화면은 WOW backend의 기존 개발용 세션을 연결한 테스트 전용입니다.</p></main>
<script>document.querySelectorAll('.user-card').forEach(btn=>btn.addEventListener('click',async()=>{{btn.disabled=true;try{{const r=await fetch('/api/auth/dev-login',{{method:'POST',credentials:'include',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{user_id:Number(btn.dataset.userId)}})}});if(!r.ok)throw new Error('login failed');location.href={safe_next!r};}}catch(e){{alert('로그인 테스트 중 오류가 발생했어요.');btn.disabled=false;}}}}));</script></body></html>"""
    return HttpResponse(page, content_type="text/html; charset=utf-8")
