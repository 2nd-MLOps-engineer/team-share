"""ServiceError 계열 예외가 View에서 그대로 새어나왔을 때의 안전망.

대부분의 View는 ServiceError를 직접 잡아서 status_code로 응답하지만,
혹시 놓친 경우에도 500 대신 의미 있는 상태 코드로 응답하기 위해 둔다.
"""
from __future__ import annotations

from rest_framework.response import Response
from rest_framework.views import exception_handler

from services.exceptions import ServiceError


def usimunkka_exception_handler(exc, context):
    if isinstance(exc, ServiceError):
        return Response({"detail": str(exc)}, status=exc.status_code)
    return exception_handler(exc, context)
