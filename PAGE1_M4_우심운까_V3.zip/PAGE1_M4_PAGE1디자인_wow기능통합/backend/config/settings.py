"""우심운까 M2 Backend 설정.

백엔드_설계.md 원칙: 지금은 DB에 연결하지 않는다. 모든 도메인 데이터는
services/repositories의 In-Memory 구현체에서 온다. django.contrib.auth /
sessions / admin 등 DB를 전제로 하는 앱은 의도적으로 쓰지 않는다
(로그인은 common/dev_session.py의 서명된 쿠키로 처리).

DATABASES를 비워두면 Django가 부팅하지 못하는 경우가 있어 sqlite 메모리
DB를 형식상 등록해두지만, 실제로 이 프로젝트의 어떤 코드도 ORM을 쓰지
않는다 — 즉 "연결되어 있지만 아무도 쓰지 않는" 상태다.
"""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-only-insecure-secret-key")
DEBUG = os.environ.get("DJANGO_DEBUG", "true").lower() == "true"
ALLOWED_HOSTS = [h.strip() for h in os.environ.get("DJANGO_ALLOWED_HOSTS", "*").split(",") if h.strip()]

INSTALLED_APPS = [
    "django.contrib.staticfiles",
    "rest_framework",
    "corsheaders",
    "users",
    "friends",
    "activities",
    "rankings",
    "facilities",
    "recommendation",
    "pipeline",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.common.CommonMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"

# 어떤 모델도 사용하지 않으므로 실질적으로 "연결되지 않은" DB다.
# (백엔드_설계.md 1~2번 참고)
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": ":memory:",
    }
}

LANGUAGE_CODE = "ko-kr"
TIME_ZONE = "Asia/Seoul"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [],
    "DEFAULT_PERMISSION_CLASSES": [],
    "UNAUTHENTICATED_USER": None,
    "EXCEPTION_HANDLER": "config.exception_handler.usimunkka_exception_handler",
}

# PAGE1_M4 프론트를 정적 서버로 띄웠을 때(dist/) 붙일 수 있도록 개발용 기본값을 넓게 둔다.
# 운영 환경에서는 반드시 실제 프론트 Origin으로 좁혀서 .env에 지정한다.
_cors_env = os.environ.get("USIMUNKKA_CORS_ORIGINS", "").strip()
if _cors_env:
    CORS_ALLOWED_ORIGINS = [origin.strip() for origin in _cors_env.split(",") if origin.strip()]
else:
    CORS_ALLOWED_ORIGINS = [
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]
CORS_ALLOW_CREDENTIALS = True

# PAGE1 design frontend used by the merged local/dev server.
FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist"
