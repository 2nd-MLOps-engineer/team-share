from django.urls import include, path, re_path

from config.frontend import frontend_asset, frontend_index, login_page

urlpatterns = [
    path("api/", include("rankings.urls")),
    path("api/", include("users.urls")),
    path("api/", include("friends.urls")),
    path("api/", include("activities.urls")),
    path("api/", include("facilities.urls")),
    path("api/", include("recommendation.urls")),
    path("api/", include("pipeline.urls")),
    path("login", login_page, name="dev-login-page"),
    path("", frontend_index, name="page1"),
    re_path(r"^(?P<path>.+)$", frontend_asset, name="frontend-asset"),
]
