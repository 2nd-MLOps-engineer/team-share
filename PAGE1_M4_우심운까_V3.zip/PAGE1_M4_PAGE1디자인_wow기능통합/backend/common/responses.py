"""M3 데이터가 필요한 기능에서 공통으로 쓰는 응답 헬퍼.

'결과 없음'과 '아직 준비 안 됨'을 구분한다 (지침서.md RULE 9/10, 55번).
HTTP 501(Not Implemented)로, 이 API가 계약상 존재하지만 아직 동작하지
않는다는 것을 명시한다.
"""
from __future__ import annotations

from rest_framework import status
from rest_framework.response import Response


def pending_data(message: str) -> Response:
    return Response(
        {"status": "PENDING_DATA", "message": message},
        status=status.HTTP_501_NOT_IMPLEMENTED,
    )
