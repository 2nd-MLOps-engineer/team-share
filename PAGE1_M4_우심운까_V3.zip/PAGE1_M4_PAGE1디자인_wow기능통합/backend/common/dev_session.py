"""개발/QA용 최소 세션 처리.

실제 인증(카카오/구글/Apple 로그인 등)은 이후 별도로 구현한다
(지침서.md 14번). 지금은 DB도, Django의 세션 프레임워크(DB 세션)도 쓰지
않기 위해 서명된 쿠키 하나로 user_id만 들고 다니는 가장 단순한 방식을 쓴다.

이 모듈은 docs/API.md의 정식 계약이 아니다. `/api/auth/dev-login`은
프론트/백엔드 통합 테스트를 위한 임시 진입점이며, 실제 서비스에서는
`/login?next=/` 로 이동하는 정식 로그인 플로우로 교체된다.
"""
from __future__ import annotations

from django.conf import settings
from django.core import signing
from django.http import HttpRequest, HttpResponse

COOKIE_NAME = "usimunkka_dev_session"
_SALT = "usimunkka.dev-session"
_MAX_AGE_SECONDS = 60 * 60 * 24 * 7


def read_user_id(request: HttpRequest) -> int | None:
    raw = request.COOKIES.get(COOKIE_NAME)
    if not raw:
        return None
    try:
        return signing.loads(raw, salt=_SALT, max_age=_MAX_AGE_SECONDS)
    except signing.BadSignature:
        return None


def set_user_id(response: HttpResponse, user_id: int) -> None:
    token = signing.dumps(user_id, salt=_SALT)
    response.set_cookie(
        COOKIE_NAME,
        token,
        httponly=True,
        samesite="Lax",
        secure=not settings.DEBUG,
        max_age=_MAX_AGE_SECONDS,
    )


def clear_session(response: HttpResponse) -> None:
    response.delete_cookie(COOKIE_NAME)
