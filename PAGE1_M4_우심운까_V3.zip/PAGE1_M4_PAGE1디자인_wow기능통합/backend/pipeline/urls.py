from django.urls import path

from pipeline.views import PipelineStatusView

urlpatterns = [
    path("admin/pipeline", PipelineStatusView.as_view(), name="admin-pipeline"),
]
