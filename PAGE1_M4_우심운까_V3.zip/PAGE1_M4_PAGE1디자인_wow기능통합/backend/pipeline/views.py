from rest_framework.views import APIView

from common.responses import pending_data


class PipelineStatusView(APIView):
    """GET /api/admin/pipeline — M3 Job이 생긴 뒤 의미가 생긴다."""

    authentication_classes: list = []
    permission_classes: list = []

    def get(self, request):
        return pending_data("Pipeline 상태는 M3 Collector/Scheduler가 준비된 뒤 제공됩니다.")
