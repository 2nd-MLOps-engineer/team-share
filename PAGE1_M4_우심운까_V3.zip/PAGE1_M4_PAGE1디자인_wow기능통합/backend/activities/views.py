from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from common.dev_session import read_user_id
from services.repositories.activity_repo import activity_log_repository

# 임시 점수 산식. 실제 산식은 docs/ACTIVITY_SCORE.md에서 별도 관리한다
# (지침서.md 28번). DB 연동 단계에서 정식 산식으로 교체한다.
_SCORE_PER_MINUTE = 2


class ActivityCompleteView(APIView):
    """POST /api/activities/complete (설정.md M2 섹션 14번).

    주의: 지금은 기록만 저장한다. 친구 랭킹/지역 활동지수는 여전히
    fixtures/activity_data.py의 고정 snapshot을 사용하므로 이 API 호출이
    바로 랭킹에 반영되지는 않는다 (DB 연동 단계에서 함께 연결 예정).
    """

    authentication_classes: list = []
    permission_classes: list = []

    def post(self, request):
        user_id = read_user_id(request)
        if user_id is None:
            return Response(status=status.HTTP_401_UNAUTHORIZED)

        sport_type = request.data.get("sport_type")
        duration_minutes = request.data.get("duration_minutes")
        facility_id = request.data.get("facility_id")

        if not sport_type or not isinstance(duration_minutes, int) or duration_minutes <= 0:
            return Response(
                {"detail": "sport_type, duration_minutes(양의 정수)가 필요합니다."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        entry = activity_log_repository.add(
            user_id=user_id,
            sport_type=sport_type,
            duration_minutes=duration_minutes,
            facility_id=facility_id,
            score=duration_minutes * _SCORE_PER_MINUTE,
        )
        return Response(
            {
                "id": entry.id,
                "score": entry.score,
                "created_at": entry.created_at,
                "note": "PENDING_DATA: 랭킹/친구 점수 자동 반영은 DB 연동 단계에서 활성화됩니다.",
            },
            status=status.HTTP_201_CREATED,
        )
