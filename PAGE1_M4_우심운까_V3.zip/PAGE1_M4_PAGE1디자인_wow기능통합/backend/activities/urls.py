from django.urls import path

from activities.views import ActivityCompleteView

urlpatterns = [
    path("activities/complete", ActivityCompleteView.as_view(), name="activities-complete"),
]
