from services.dto import User


def serialize_user(user: User) -> dict:
    """docs/API.md '로그인 사용자 주소지 → MY REGION 표시 계약'과 동일한 필드."""
    return {
        "id": user.id,
        "nickname": user.nickname,
        "friend_code": user.friend_code,
        "province": user.province,
        "region_code": user.region_code,
        "region_name": user.region_name,
        "address": user.address,
    }
