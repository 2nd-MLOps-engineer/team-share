from django.urls import path

from users.views import DevLoginView, LogoutView, MeView

urlpatterns = [
    path("users/me", MeView.as_view(), name="users-me"),
    path("auth/dev-login", DevLoginView.as_view(), name="auth-dev-login"),
    path("auth/logout", LogoutView.as_view(), name="auth-logout"),
]
