from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from common.dev_session import clear_session, read_user_id, set_user_id
from services.repositories.user_repo import user_repository
from users.serializers import serialize_user


class MeView(APIView):
    """GET /api/users/me — 인증 필요, 미인증은 401 (docs/API.md)."""

    authentication_classes: list = []
    permission_classes: list = []

    def get(self, request):
        user_id = read_user_id(request)
        user = user_repository.get(user_id) if user_id is not None else None
        if user is None:
            return Response(status=status.HTTP_401_UNAUTHORIZED)
        return Response(serialize_user(user))


class DevLoginView(APIView):
    """POST /api/auth/dev-login — docs/API.md 정식 계약이 아닌 개발/QA 전용 진입점.

    실제 로그인은 `/login?next=/` 로 이동하는 정식 플로우로 대체될 예정이다
    (지침서.md 14번, 설정.md M1 18번). DB/OAuth가 준비되기 전까지 프론트-백엔드
    통합 테스트를 위해서만 사용한다.
    """

    authentication_classes: list = []
    permission_classes: list = []

    def post(self, request):
        requested_id = request.data.get("user_id", 7)
        try:
            user_id = int(requested_id)
        except (TypeError, ValueError):
            return Response({"detail": "user_id는 정수여야 합니다."}, status=status.HTTP_400_BAD_REQUEST)
        user = user_repository.get(user_id)
        if user is None:
            return Response({"detail": "존재하지 않는 사용자입니다."}, status=status.HTTP_404_NOT_FOUND)
        response = Response(serialize_user(user))
        set_user_id(response, user.id)
        return response


class LogoutView(APIView):
    """POST /api/auth/logout — docs/API.md."""

    authentication_classes: list = []
    permission_classes: list = []

    def post(self, request):
        response = Response(status=status.HTTP_204_NO_CONTENT)
        clear_session(response)
        return response
