#!/bin/sh
set -eu
cd "$(dirname "$0")/backend"
python3 manage.py runserver 127.0.0.1:8000
