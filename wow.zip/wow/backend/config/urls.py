from django.urls import include, path

urlpatterns = [
    path("api/", include("rankings.urls")),
    path("api/", include("users.urls")),
    path("api/", include("friends.urls")),
    path("api/", include("activities.urls")),
    path("api/", include("facilities.urls")),
    path("api/", include("recommendation.urls")),
    path("api/", include("pipeline.urls")),
]
