(() => {
  const app = window.USIMUNKKA;
  const profile = app.getProfile();
  const $ = s => document.querySelector(s);
  const setValue = (s, v) => { const el = $(s); if (el) el.value = v ?? ""; };

  setValue("#nicknameInput", profile.nickname);
  setValue("#messageInput", profile.message);
  setValue("#profileProvince", profile.province);
  setValue("#profileDistrict", profile.district);
  setValue("#profileNeighborhood", profile.neighborhood);
  setValue("#profileTransport", profile.transport);
  setValue("#profileTravelMinutes", profile.max_travel_minutes);
  $("#friendCodeText").textContent = profile.friend_code;
  const gender = profile.avatar_gender || "female";

  document
    .querySelectorAll('input[name="avatarGender"]')
    .forEach(input => {
      input.checked = input.value === gender;
    });
  const profileImage = $("#profileEditAvatarImage");

if (profileImage) {
  const femaleSrc =
    profileImage.dataset.femaleSrc ||
    profileImage.dataset.defaultSrc ||
    profileImage.getAttribute("src");

  const maleSrc =
    profileImage.dataset.maleSrc ||
    profileImage.dataset.defaultSrc ||
    profileImage.getAttribute("src");

  const updateAvatarImage = selectedGender => {
    profileImage.src =
      selectedGender === "male"
        ? maleSrc
        : femaleSrc;
  };

  // 저장되어 있는 성별의 캐릭터 표시
  updateAvatarImage(gender);

  // 여성 / 남성 버튼을 누르면 즉시 캐릭터 변경
  document
    .querySelectorAll('input[name="avatarGender"]')
    .forEach(input => {
      input.addEventListener("change", () => {
        if (input.checked) {
          updateAvatarImage(input.value);
        }
      });
    });
}

  document.querySelectorAll("#profileSportChecks input").forEach(input => {
    input.checked = profile.preferred_sports.includes(input.value);
  });

  $("#profileForm").addEventListener("submit", event => {
    event.preventDefault();
    const sports = [...document.querySelectorAll("#profileSportChecks input:checked")].map(input => input.value);
    if (!sports.length) {
      alert("좋아하는 운동을 하나 이상 선택해주세요.");
      return;
    }
    const saved = app.saveProfile({
      ...profile,
      nickname: $("#nicknameInput").value.trim(),
      message: $("#messageInput").value.trim(),
      avatar_gender:
          document.querySelector('input[name="avatarGender"]:checked')?.value || "female",
      province: $("#profileProvince").value.trim(),
      district: $("#profileDistrict").value.trim(),
      neighborhood: $("#profileNeighborhood").value.trim(),
      preferred_sports: sports,
      transport: $("#profileTransport").value,
      max_travel_minutes: Number($("#profileTravelMinutes").value),
    });
    const message = $("#profileSaveMessage");
    message.textContent = `${saved.nickname}님의 추천 기본값을 저장했어요. HOME에 바로 반영됩니다.`;
    message.classList.add("is-success");
    setTimeout(() => location.href = "/", 700);
  });
})();
