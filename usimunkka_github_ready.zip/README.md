# 우심운까 PAGE 1

GitHub 공유용 랜딩페이지입니다.

## 실행
- `index.html`을 브라우저에서 열면 됩니다.
- GitHub Pages 사용 시 저장소 루트에 `index.html`을 올리면 됩니다.

## 포함 기능
- 지역별 랭킹 지도
- 지역 팝업 및 마스코트
- 데이터 기반 1위 지역 3D 챔피언 마스코트 전환
- MY REGION / 친구 랭킹 UI
