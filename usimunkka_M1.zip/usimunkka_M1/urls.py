from django.urls import path

from . import views
from .profile_demo import demo_recommendations


urlpatterns = [
    path("", views.index, name="index"),
    path("login/", views.login_page, name="login"),
    path("profile/clear/", views.clear_profile, name="profile_clear"),

    # 추천 페이지를 데이터 원천별로 완전히 분리
    path("recommend/home/", views.recommend_home, name="recommend_home"),
    path("recommend/custom/", views.recommend_custom, name="recommend_custom"),

    # 예전 링크 호환용: /recommend/ -> /recommend/home/
    path("recommend/", views.recommend, name="recommend"),

    path("demo-api/recommendations/", demo_recommendations, name="profile_demo_recommendations"),
    path("local/", views.local_consumption, name="local_consumption"),
]
