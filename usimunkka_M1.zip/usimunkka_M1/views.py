from django.shortcuts import redirect, render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_http_methods, require_POST

from .forms import ProfileStartForm
from .profile_demo import PROFILE_SESSION_KEY, get_saved_profile


@never_cache
def index(request):
    """PAGE 1 - 메인 / 지역 랭킹 화면."""
    profile = get_saved_profile(request)

    return render(
        request,
        "frontend/index.html",
        {
            "profile": profile,
            "has_profile": bool(profile),
        },
    )


@never_cache
@require_http_methods(["GET", "POST"])
def login_page(request):
    """간편 프로필 입력. 성공하면 메인 페이지로 돌아간다."""
    if request.method == "POST":
        form = ProfileStartForm(request.POST)

        if form.is_valid():
            request.session[PROFILE_SESSION_KEY] = dict(form.cleaned_data)
            request.session.set_expiry(0)
            return redirect("index")
    else:
        form = ProfileStartForm(
            initial=request.session.get(PROFILE_SESSION_KEY, {})
        )

    return render(
        request,
        "frontend/login.html",
        {
            "form": form,
            "has_profile": bool(request.session.get(PROFILE_SESSION_KEY)),
        },
    )


@never_cache
def recommend(request):
    """기존 /recommend/ 주소 호환용. 내 지역 추천 화면으로 보낸다."""
    return redirect("recommend_home")


@never_cache
def recommend_home(request):
    """
    내 지역 추천 전용 화면.

    데이터 원천은 로그인 세션의 profile.city 하나만 사용한다.
    다른 지역 선택값(target_region)은 이 view에서 읽지 않는다.
    """
    profile = get_saved_profile(request)

    if profile is None:
        return redirect("login")

    selected_region = str(profile.get("city", "")).strip()

    if not selected_region:
        return redirect("login")

    return render(
        request,
        "frontend/recommend_home.html",
        {
            "profile": profile,
            "selected_region": selected_region,
            "recommend_mode": "home",
        },
    )


@never_cache
def recommend_custom(request):
    """
    다른 지역 추천 전용 화면.

    데이터 원천은 이 요청의 target_region query parameter만 사용한다.
    profile.city는 사용자 표시용으로만 남고 추천 지역을 덮어쓰지 않는다.
    """
    profile = get_saved_profile(request)

    if profile is None:
        return redirect("login")

    selected_region = request.GET.get("target_region", "").strip()

    if not selected_region:
        return redirect("index")

    return render(
        request,
        "frontend/recommend_custom.html",
        {
            "profile": profile,
            "selected_region": selected_region,
            "recommend_mode": "custom",
        },
    )


@never_cache
@require_POST
def clear_profile(request):
    """저장된 프로필 삭제 후 로그인으로 이동."""
    request.session.pop(PROFILE_SESSION_KEY, None)
    return redirect("login")


@never_cache
def local_consumption(request):
    """운동 후 지역 소비 페이지."""
    profile = get_saved_profile(request)

    return render(
        request,
        "frontend/local_consumption.html",
        {
            "profile": profile,
        },
    )
