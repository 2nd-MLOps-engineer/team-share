from django import forms


class ProfileStartForm(forms.Form):
    """우심운까 간편 프로필 입력 폼."""

    AGE_GROUP_CHOICES = [
        ("10대", "10대"),
        ("20대", "20대"),
        ("30대", "30대"),
        ("40대", "40대"),
        ("50대", "50대"),
        ("60대 이상", "60대 이상"),
    ]

    nickname = forms.CharField(
        label="닉네임",
        max_length=20,
        strip=True,
    )

    age_group = forms.ChoiceField(
        label="나이대",
        choices=AGE_GROUP_CHOICES,
    )

    city = forms.CharField(
        label="사는 지역",
        max_length=40,
        strip=True,
    )

    def clean_nickname(self):
        nickname = self.cleaned_data["nickname"].strip()
        if "<" in nickname or ">" in nickname:
            raise forms.ValidationError("닉네임에는 꺾쇠 기호를 사용할 수 없습니다.")
        return nickname

    def clean_city(self):
        city = self.cleaned_data["city"].strip()
        if "<" in city or ">" in city:
            raise forms.ValidationError("지역명에는 꺾쇠 기호를 사용할 수 없습니다.")
        return city
