[우심운까 v1 설치 경로]

1. C 드라이브에 아래 폴더를 만듭니다.

C:\usimunkka_v1

2. ZIP 안의 파일/폴더를 전부 C:\usimunkka_v1 바로 아래에 압축 해제합니다.

정상 구조 예시:

C:\usimunkka_v1\manage.py
C:\usimunkka_v1\requirements.txt
C:\usimunkka_v1\config\settings.py
C:\usimunkka_v1\frontend\views.py
C:\usimunkka_v1\frontend\templates\frontend\home.html
C:\usimunkka_v1\frontend\static\frontend\css\base.css
C:\usimunkka_v1\frontend\static\frontend\js\api.js

주의:
C:\usimunkka_v1\usimunkka_v1\manage.py 처럼 폴더가 두 겹이 되지 않게 해주세요.

3. CMD 또는 VS Code 터미널에서 실행

cd C:\usimunkka_v1
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver

4. 브라우저

http://127.0.0.1:8000/

[페이지 경로]

HOME        http://127.0.0.1:8000/
운동추천     http://127.0.0.1:8000/recommend/
운동일지     http://127.0.0.1:8000/diary/
친구         http://127.0.0.1:8000/friends/
프로필       http://127.0.0.1:8000/profile/

[현재 버전에서 꼭 확인할 것]

- 프로필에서 서울특별시 / 관악구 등을 다른 값으로 변경
- 선호 운동 변경
- 이동수단 / 이동 가능시간 변경
- 저장 후 HOME 이동
- HOME의 기본 추천 지역/운동 정보가 변경되는지 확인
- 운동추천 탭에서 프로필 값이 기본값으로 자동 로드되는지 확인

[Backend 연결 핵심 파일]

C:\usimunkka_v1\frontend\static\frontend\js\api.js

현재는 프론트 구조 확인을 위해 localStorage + MOCK 추천을 사용합니다.
실제 DB/Backend 연결 시 화면을 고치기보다 api.js 내부 메서드를 기존 API 호출로 교체하는 구조입니다.
