# Backend / DB 연결 가이드 — Frontend v4

## 원칙

Frontend는 DB를 직접 조회하지 않습니다.
Backend API가 JSON을 전달하고 Frontend는 `frontend/static/frontend/js/api.js`를 통해 사용합니다.

v4는 Frontend 전면 재설계이며 DB / Backend 구조 변경을 요구하지 않습니다.

## 프로필에서 필요한 데이터 예시

```json
{
  "id": 7,
  "nickname": "우심이",
  "message": "오늘도 일단 움직이자.",
  "friend_code": "USIM-7K29",
  "province": "서울특별시",
  "district": "관악구",
  "neighborhood": "봉천동",
  "preferred_sports": ["running", "fitness"],
  "transport": "walk",
  "max_travel_minutes": 20,
  "streak_days": 4
}
```

HOME 자동 추천에 직접 사용하는 값:

```text
province
district
preferred_sports
transport
max_travel_minutes
```

## 운동 종목 key

```text
running   → 러닝
cycling   → 자전거
crossfit  → 크로스핏
fitness   → 헬스
```

Frontend는 과거 브라우저 데이터에 `hyrox`가 남아 있을 경우에만 호환 목적으로 `crossfit`으로 변환합니다.
새 API 데이터는 `crossfit`을 사용하세요.

## 운동추천 요청 예시

```json
{
  "province": "서울특별시",
  "district": "관악구",
  "sport": "crossfit",
  "available_minutes": 60,
  "transport": "walk",
  "max_travel_minutes": 20
}
```

## 운동추천 응답 예시

```json
[
  {
    "id": 101,
    "name": "관악 크로스핏 박스",
    "sport": "crossfit",
    "province": "서울특별시",
    "district": "관악구",
    "travel_minutes": 16,
    "available_exercise_minutes": 28,
    "indoor": true,
    "score": 89,
    "reasons": [
      "이동 범위 안",
      "실내 운동",
      "기능성 트레이닝"
    ]
  }
]
```

숫자 값은 문자열로 가공해서 보내지 않는 것을 권장합니다.
예: `"20분"` 대신 `20`, `"89점"` 대신 `89`.

## 기존 알려진 API와의 관계

이전 Frontend에서 사용된 적 있는 경로:

```text
GET /api/users/me
GET /api/rankings
GET /api/friends/ranking
```

실제 팀 Backend 계약이 확정되면 `api.js` 내부 구현만 fetch 기반으로 교체하고 HTML/CSS는 유지합니다.
