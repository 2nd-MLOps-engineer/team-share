# Frontend v4 Architecture

## 1. 디자인 원칙

```text
싸이월드 레이아웃 복제 X
개인화/꾸미기/친구 관계 개념만 차용 O

SPORTS EDITORIAL
+ LARGE DESKTOP LAYOUT
+ PROFILE-BASED RECOMMENDATION
+ CUSTOMIZABLE MOVE ID
```

한 화면에 작은 위젯을 많이 배치하지 않습니다.
각 페이지는 큰 Hero, 핵심 기능, 보조 정보 2~3개 덩어리로 구성합니다.

## 2. HOME

가장 먼저 보여야 하는 것은 `오늘 실제로 갈 수 있는 운동`입니다.

```text
PROFILE DEFAULT
지역 / 선호 운동 / 이동수단 / 이동시간
        ↓
TODAY'S MOVE
        ↓
추천 장소 / 이동시간 / 운동 가능시간 / 추천 이유
```

오른쪽 `MY MOVE ID`는 개인화 장치이며 추천 기능보다 우선하지 않습니다.

## 3. MOVE

큰 조건 입력 영역 + 큰 결과 영역 2분할 구조.

입력:
- 출발 지역
- 가능한 전체 시간
- 운동 종목 1개
- 이동수단
- 최대 이동시간

종목:
- RUNNING
- CYCLING
- CROSSFIT
- FITNESS

## 4. RECORD

이번 기간의 총 칼로리, 운동 횟수, streak를 크게 보여주고 최근 운동을 스트림 형태로 표시합니다.
운동 완료 입력은 기존 결정대로 `소모 칼로리 1개`를 기준으로 합니다.

## 5. CREW

친구 운동 상태를 카드 여러 개가 아닌 activity stream으로 보여줍니다.
친구 코드와 짧은 메시지는 유지합니다.

## 6. MY

프로필은 자기소개 페이지인 동시에 추천 엔진의 기본값 저장소입니다.

추천 기본값:
- province
- district
- preferred_sports
- transport
- max_travel_minutes

## 7. API 분리

HTML에서 API URL을 직접 호출하지 않습니다.

```text
HTML / UI
   ↓
frontend/static/frontend/js/api.js
   ↓
Backend API
   ↓
DB
```
