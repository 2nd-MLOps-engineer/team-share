from django.shortcuts import render


def home(request):
    return render(request, "frontend/home.html", {"active_tab": "home"})


def recommend(request):
    return render(request, "frontend/recommend.html", {"active_tab": "recommend"})


def diary(request):
    return render(request, "frontend/diary.html", {"active_tab": "diary"})


def friends(request):
    return render(request, "frontend/friends.html", {"active_tab": "friends"})


def profile(request):
    return render(request, "frontend/profile.html", {"active_tab": "profile"})
