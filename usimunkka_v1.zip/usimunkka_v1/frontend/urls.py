from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("recommend/", views.recommend, name="recommend"),
    path("diary/", views.diary, name="diary"),
    path("friends/", views.friends, name="friends"),
    path("profile/", views.profile, name="profile"),
]
