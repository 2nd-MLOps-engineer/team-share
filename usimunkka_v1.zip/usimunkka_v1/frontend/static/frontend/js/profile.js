(() => {
  const app = window.USIMUNKKA;
  const profile = app.getProfile();
  const $ = s => document.querySelector(s);
  const setValue = (s, v) => { const el = $(s); if (el) el.value = v ?? ""; };

  setValue("#nicknameInput", profile.nickname);
  setValue("#messageInput", profile.message);
  setValue("#profileProvince", profile.province);
  setValue("#profileDistrict", profile.district);
  setValue("#profileNeighborhood", profile.neighborhood);
  setValue("#profileTransport", profile.transport);
  setValue("#profileTravelMinutes", profile.max_travel_minutes);
  $("#friendCodeText").textContent = profile.friend_code;
  const profileImage = $("#profileEditAvatarImage");
  if (profileImage) {
    const fallback = profileImage.dataset.defaultSrc || profileImage.getAttribute("src") || "";
    const custom = profile.image_url || profile.profile_image || profile.image || "";
    profileImage.src = custom || fallback;
    profileImage.addEventListener("error", () => { profileImage.src = fallback; }, { once: true });
  }

  document.querySelectorAll("#profileSportChecks input").forEach(input => {
    input.checked = profile.preferred_sports.includes(input.value);
  });

  $("#profileForm").addEventListener("submit", event => {
    event.preventDefault();
    const sports = [...document.querySelectorAll("#profileSportChecks input:checked")].map(input => input.value);
    if (!sports.length) {
      alert("좋아하는 운동을 하나 이상 선택해주세요.");
      return;
    }
    const saved = app.saveProfile({
      ...profile,
      nickname: $("#nicknameInput").value.trim(),
      message: $("#messageInput").value.trim(),
      province: $("#profileProvince").value.trim(),
      district: $("#profileDistrict").value.trim(),
      neighborhood: $("#profileNeighborhood").value.trim(),
      preferred_sports: sports,
      transport: $("#profileTransport").value,
      max_travel_minutes: Number($("#profileTravelMinutes").value),
    });
    const message = $("#profileSaveMessage");
    message.textContent = `${saved.nickname}님의 추천 기본값을 저장했어요. HOME에 바로 반영됩니다.`;
    message.classList.add("is-success");
    setTimeout(() => location.href = "/", 700);
  });
})();
