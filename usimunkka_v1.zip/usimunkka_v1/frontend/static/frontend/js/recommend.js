(() => {
  const app = window.USIMUNKKA;
  const profile = app.getProfile();
  const $ = s => document.querySelector(s);
  const escapeHtml = value => String(value ?? "").replace(/[&<>'"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch]));

  $("#provinceInput").value = profile.province;
  $("#districtInput").value = profile.district;
  $("#transportSelect").value = profile.transport;
  $("#travelMinutesSelect").value = String(profile.max_travel_minutes);
  const preferred = profile.preferred_sports?.[0] || "running";
  const initialSport = document.querySelector(`input[name='sport'][value='${preferred}']`) || document.querySelector("input[name='sport']");
  if (initialSport) initialSport.checked = true;

  const renderResults = rows => {
    $("#recommendResults").innerHTML = rows.map((row, index) => `
      <article class="result-card">
        <span class="result-rank">${String(index + 1).padStart(2,"0")}</span>
        <span class="result-eyebrow">${escapeHtml(app.SPORT_META[row.sport]?.label || row.type)} PICK</span>
        <h3>${escapeHtml(row.name)}</h3>
        <p class="result-meta">${escapeHtml(row.province)} ${escapeHtml(row.district)} · ${row.indoor ? "실내" : "야외"} · 이동 ${row.travel_minutes}분</p>
        <div class="result-score"><strong>${row.score}</strong><span>실행 적합도 / 100</span></div>
        <div class="reason-list">${row.reasons.map(reason => `<span>${escapeHtml(reason)}</span>`).join("")}</div>
        <p class="result-meta">예상 운동 가능시간 ${row.available_exercise_minutes}분</p>
        <div class="result-actions"><button type="button">상세 보기</button><button type="button" class="primary-mini">이 운동으로 결정</button></div>
      </article>
    `).join("");
  };

  $("#recommendForm").addEventListener("submit", async event => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const sport = data.get("sport");
    if (!sport) { alert("오늘 하고 싶은 운동을 하나 선택해주세요."); return; }
    $("#recommendResults").innerHTML = `<div class="empty-result-v4"><span>…</span><b>지금 갈 수 있는 운동을 찾고 있어요.</b><small>프로필과 오늘 조건을 함께 확인 중입니다.</small></div>`;
    const rows = await app.recommend({
      province: $("#provinceInput").value.trim(),
      district: $("#districtInput").value.trim(),
      sport,
      available_minutes: Number(data.get("available_minutes")),
      transport: $("#transportSelect").value,
      max_travel_minutes: Number($("#travelMinutesSelect").value),
    });
    renderResults(rows);
  });
})();
