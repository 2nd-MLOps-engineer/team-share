(() => {
  const app = window.USIMUNKKA;
  if (!app) return;

  const profile = app.getProfile();
  const $ = selector => document.querySelector(selector);
  const set = (selector, value) => {
    const el = $(selector);
    if (el) el.textContent = value;
  };
  const sportLabel = sport => app.SPORT_META[sport]?.label || sport;
  const transportLabel = app.TRANSPORT_META[profile.transport] || profile.transport;

  const ROOM_STATE_KEY = "usimunkka.v1.room.state.v91";
  const LAYOUT_KEY = "usimunkka.v1.room.layout.v91";
  const defaultVisible = {
    window: true,
    poster: true,
    bed: true,
    shelf: true,
    desk: true,
    rug: true,
    plant: true,
    lamp: true,
    character: true,
    dumbbell: false,
    basketball: false,
    gymbag: false,
  };
  const defaultState = { tone: "cream", visible: { ...defaultVisible } };

  const safeJson = (key, fallback) => {
    try {
      const parsed = JSON.parse(localStorage.getItem(key) || "null");
      return parsed && typeof parsed === "object" ? parsed : fallback;
    } catch (_) {
      return fallback;
    }
  };

  const readRoomState = () => {
    const stored = safeJson(ROOM_STATE_KEY, {});
    const tone = ["cream", "sage", "blue"].includes(stored.tone) ? stored.tone : defaultState.tone;
    return {
      tone,
      visible: { ...defaultVisible, ...(stored.visible || {}) },
    };
  };

  let savedState = readRoomState();
  let draftState = JSON.parse(JSON.stringify(savedState));

  set("#homeNickname", profile.nickname);
  set("#homeRegion", `${profile.province} ${profile.district}`);
  set("#homePreference", `${profile.preferred_sports.map(sportLabel).join(" · ")} · ${transportLabel} ${profile.max_travel_minutes}분 기준`);

  const applyRoomState = state => {
    const room = $("#sportsRoom");
    if (!room) return;
    room.dataset.tone = state.tone;
    document.querySelectorAll("[data-room-item]").forEach(item => {
      const key = item.dataset.roomItem;
      const visible = state.visible[key] !== false;
      item.classList.toggle("is-room-hidden", !visible);
    });
  };

  const syncCustomizer = () => {
    document.querySelectorAll("[data-tone]").forEach(button => {
      button.classList.toggle("is-selected", button.dataset.tone === draftState.tone);
    });
    document.querySelectorAll("[data-toggle-item]").forEach(button => {
      const key = button.dataset.toggleItem;
      button.classList.toggle("is-selected", draftState.visible[key] !== false);
    });
    applyRoomState(draftState);
  };

  const openCustomizer = () => {
    draftState = JSON.parse(JSON.stringify(savedState));
    syncCustomizer();
    const backdrop = $("#customizerBackdrop");
    if (backdrop) backdrop.hidden = false;
    document.body.style.overflow = "hidden";
  };

  const closeCustomizer = restore => {
    if (restore) applyRoomState(savedState);
    const backdrop = $("#customizerBackdrop");
    if (backdrop) backdrop.hidden = true;
    document.body.style.overflow = "";
  };

  $("#openCustomizer")?.addEventListener("click", openCustomizer);
  $("#closeCustomizer")?.addEventListener("click", () => closeCustomizer(true));
  $("#customizerBackdrop")?.addEventListener("click", event => {
    if (event.target === event.currentTarget) closeCustomizer(true);
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !$("#customizerBackdrop")?.hidden) closeCustomizer(true);
  });

  document.querySelectorAll("[data-tone]").forEach(button => {
    button.addEventListener("click", () => {
      draftState.tone = button.dataset.tone;
      syncCustomizer();
    });
  });

  document.querySelectorAll("[data-toggle-item]").forEach(button => {
    button.addEventListener("click", () => {
      const key = button.dataset.toggleItem;
      draftState.visible[key] = !(draftState.visible[key] !== false);
      syncCustomizer();
    });
  });

  $("#saveCustomizer")?.addEventListener("click", () => {
    savedState = JSON.parse(JSON.stringify(draftState));
    localStorage.setItem(ROOM_STATE_KEY, JSON.stringify(savedState));
    applyRoomState(savedState);
    set("#customizerSaveMessage", "저장했어요. 내 방에 바로 반영됐어요.");
    window.setTimeout(() => closeCustomizer(false), 450);
  });

  const roomScene = $("#roomScene");
  const draggableItems = [...document.querySelectorAll("[data-room-item]")];
  let activeDrag = null;

  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const getLimits = item => ({
    minX: Number(item.dataset.minX || 5),
    maxX: Number(item.dataset.maxX || 95),
    minY: Number(item.dataset.minY || 10),
    maxY: Number(item.dataset.maxY || 91),
  });

  const setItemPosition = (item, x, y, save = false) => {
    const limits = getLimits(item);
    const nx = clamp(Number(x), limits.minX, limits.maxX);
    const ny = clamp(Number(y), limits.minY, limits.maxY);
    item.style.left = `${nx}%`;
    item.style.top = `${ny}%`;
    item.dataset.x = String(nx);
    item.dataset.y = String(ny);
    if (save) saveLayout();
  };

  const saveLayout = () => {
    const state = {};
    draggableItems.forEach(item => {
      state[item.dataset.roomItem] = {
        x: Number(item.dataset.x || item.dataset.defaultX || 50),
        y: Number(item.dataset.y || item.dataset.defaultY || 50),
      };
    });
    localStorage.setItem(LAYOUT_KEY, JSON.stringify(state));
  };

  const restoreLayout = () => {
    const savedLayout = safeJson(LAYOUT_KEY, {});
    draggableItems.forEach(item => {
      const key = item.dataset.roomItem;
      const saved = savedLayout[key];
      const x = saved?.x ?? Number(item.dataset.defaultX || 50);
      const y = saved?.y ?? Number(item.dataset.defaultY || 50);
      setItemPosition(item, x, y, false);
    });
  };

  const pointerPosition = event => {
    const rect = roomScene.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / rect.width) * 100,
      y: ((event.clientY - rect.top) / rect.height) * 100,
    };
  };

  draggableItems.forEach(item => {
    item.addEventListener("pointerdown", event => {
      if (item.classList.contains("is-room-hidden")) return;
      if (event.button !== undefined && event.button !== 0) return;
      const sceneRect = roomScene.getBoundingClientRect();
      const itemRect = item.getBoundingClientRect();
      activeDrag = {
        item,
        offsetX: ((event.clientX - (itemRect.left + itemRect.width / 2)) / sceneRect.width) * 100,
        offsetY: ((event.clientY - (itemRect.top + itemRect.height / 2)) / sceneRect.height) * 100,
      };
      item.classList.add("is-dragging");
      item.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    });

    item.addEventListener("pointermove", event => {
      if (activeDrag?.item !== item) return;
      const pos = pointerPosition(event);
      setItemPosition(item, pos.x - activeDrag.offsetX, pos.y - activeDrag.offsetY, false);
    });

    const endDrag = event => {
      if (activeDrag?.item !== item) return;
      item.classList.remove("is-dragging");
      item.releasePointerCapture?.(event.pointerId);
      activeDrag = null;
      saveLayout();
    };
    item.addEventListener("pointerup", endDrag);
    item.addEventListener("pointercancel", endDrag);

    item.addEventListener("keydown", event => {
      if (item.classList.contains("is-room-hidden")) return;
      const keys = ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"];
      if (!keys.includes(event.key)) return;
      event.preventDefault();
      const step = event.shiftKey ? 3 : 1;
      let x = Number(item.dataset.x || item.dataset.defaultX || 50);
      let y = Number(item.dataset.y || item.dataset.defaultY || 50);
      if (event.key === "ArrowLeft") x -= step;
      if (event.key === "ArrowRight") x += step;
      if (event.key === "ArrowUp") y -= step;
      if (event.key === "ArrowDown") y += step;
      setItemPosition(item, x, y, true);
    });
  });

  $("#resetRoomLayout")?.addEventListener("click", () => {
    draggableItems.forEach(item => {
      setItemPosition(item, Number(item.dataset.defaultX || 50), Number(item.dataset.defaultY || 50), false);
    });
    localStorage.removeItem(LAYOUT_KEY);
  });

  const sportBadge = sport => ({ running: "RUN", cycling: "RIDE", crossfit: "CF", fitness: "GYM" }[sport] || "MOVE");

  const renderQuick = async () => {
    const minutes = Number($("#quickMinutes")?.value || 60);
    const result = await app.getQuickRecommendation(profile, minutes);
    set("#spotlightIcon", sportBadge(result.sport));
    set("#spotlightSport", sportLabel(result.sport));
    set("#spotlightTitle", result.name);
    set("#spotlightMeta", `${sportLabel(result.sport)} · ${transportLabel} ${result.travel_minutes}분 · ${result.indoor ? "실내" : "야외"}`);
    const tags = $("#spotlightTags");
    if (tags) tags.innerHTML = result.reasons.slice(0, 2).map(reason => `<span>${reason}</span>`).join("");
  };

  const renderTalks = () => {
    const list = $("#homeTalkList");
    if (!list) return;
    list.innerHTML = app.getTalks().slice(0, 3).map(row => `
      <div class="talk-row"><b>${row.author}</b><span>${row.text}</span><time>${row.time}</time></div>
    `).join("");
  };

  $("#quickRecommendButton")?.addEventListener("click", renderQuick);
  $("#quickMinutes")?.addEventListener("change", renderQuick);
  $("#homeTalkForm")?.addEventListener("submit", event => {
    event.preventDefault();
    const input = $("#homeTalkInput");
    const text = input.value.trim();
    if (!text) return;
    app.addTalk(text, profile.nickname);
    input.value = "";
    renderTalks();
  });

  applyRoomState(savedState);
  restoreLayout();
  renderTalks();
  renderQuick();
})();