(() => {
  const app = window.USIMUNKKA;
  const profile = app.getProfile();
  const $ = s => document.querySelector(s);
  const friends = app.getFriends();
  $("#myFriendCode").textContent = profile.friend_code;
  $("#friendCount").textContent = friends.length;
  $("#friendCards").innerHTML = friends.map(friend => `
    <article class="friend-card">
      <div class="friend-card-head"><span class="friend-mini-avatar" style="background:${friend.color}">${friend.nickname.slice(0,1)}</span><div><h3>${friend.nickname}</h3><small>${friend.region}</small></div></div>
      <p>${friend.status}</p>
      <strong>${friend.calories ? `${friend.calories} kcal 🔥` : "운동 기다리는 중"}</strong>
    </article>
  `).join("");

  const renderGuestbook = () => {
    $("#guestbookList").innerHTML = app.getTalks().slice(0, 8).map(row => `<div class="guestbook-row"><b>${row.author}</b><span>${row.text}</span><time>${row.time}</time></div>`).join("");
  };
  renderGuestbook();

  $("#guestbookForm").addEventListener("submit", event => {
    event.preventDefault();
    const input = $("#guestbookInput");
    const text = input.value.trim();
    if (!text) return;
    app.addTalk(text, profile.nickname);
    input.value = "";
    renderGuestbook();
  });

  $("#friendAddForm").addEventListener("submit", event => {
    event.preventDefault();
    const code = $("#friendCodeInput").value.trim();
    $("#friendAddFeedback").textContent = code ? `${code} 입력 확인. 실제 연결 시 기존 친구 API에 POST 하도록 교체하세요.` : "친구 코드를 입력해주세요.";
  });
})();
