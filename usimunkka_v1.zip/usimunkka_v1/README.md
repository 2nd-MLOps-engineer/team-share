# 우심운까 v1 — MY MOVE HOME

싸이월드 미니홈피의 **개인 공간 / 프로필 / 책갈피 / 친구 한마디** 구조를 가져오되,
우심운까의 핵심인 **운동 장소 추천**이 가장 먼저 보이도록 다시 설계한 데스크톱 웹 프론트 프로토타입입니다.

## 핵심 원칙

- 새 작업 루트: `C:\usimunkka_v1`
- 기존 `C:\usimunkka` 프론트 파일을 덮어쓰지 않음
- DB / Backend 구조 변경을 전제로 하지 않음
- 프로필의 지역/선호운동/이동수단/이동시간을 HOME 추천 기본값으로 사용
- HOME에는 `TODAY'S MOVE` 자동 추천을 항상 노출
- 상세 조건 변경은 `운동추천` 책갈피에서 처리
- 모바일 GPS/백그라운드 위치 추적을 핵심 기능으로 사용하지 않음

## 현재 v1 구현 범위

1. HOME
   - 미니홈피형 레이아웃
   - 프로필 사이드바
   - 미니룸 + 펫
   - 프로필 기반 빠른 운동 추천
   - 오늘 상태
   - 친구 한마디
2. 운동추천
   - 프로필 기본 지역/운동/이동조건 자동 입력
   - 오늘 시간/지역/종목/이동조건 변경
   - MOCK 추천 결과 출력
3. 운동일지
   - 칼로리 기준 운동 기록 예시
4. 친구
   - 친구 코드 UI
   - 친구 운동 상태
   - 방명록/한마디
5. 프로필
   - 닉네임 / 한줄소개
   - 추천용 기본 지역
   - 선호 운동
   - 이동수단 / 이동 가능시간

## 중요한 데이터 상태

이 압축본은 **프론트 구조를 먼저 확정하기 위한 v1 프로토타입**입니다.
프로필/친구 한마디/운동일지는 브라우저 `localStorage`를 사용하므로 DB 스키마를 변경하지 않습니다.

실제 Backend와 연결할 때는 `frontend/static/frontend/js/api.js`의 메서드 내부만 기존 API 호출로 교체합니다.
화면 파일에서 직접 API URL을 호출하지 않도록 분리해두었습니다.

## Windows 실행

```bat
cd C:\usimunkka_v1
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

브라우저:

```text
http://127.0.0.1:8000/
```

프로필 페이지에서 값을 수정하고 저장한 뒤 HOME으로 돌아오면 추천 기본 정보가 바로 바뀝니다.

## 기존 Backend 연결 시

아래 파일 하나를 첫 연결 지점으로 사용하세요.

```text
C:\usimunkka_v1\frontend\static\frontend\js\api.js
```

자세한 데이터 계약 제안은 `docs/BACKEND_HANDOFF.md` 참고.
